import { createFileRoute } from "@tanstack/react-router";
import { Desk } from "@/components/desk";
import { listMarkets } from "@/lib/markets-api";
import type { MarketEvent } from "@/lib/types";

export const Route = createFileRoute("/")({
  loader: async (): Promise<MarketEvent[]> => {
    const res = await listMarkets({ data: {} });
    return res.ok ? res.events : [];
  },
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  return <Desk initialEvents={initial} />;
}
