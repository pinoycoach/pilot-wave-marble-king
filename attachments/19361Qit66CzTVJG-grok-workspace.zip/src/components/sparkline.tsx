import type { PricePoint } from "@/lib/types";
import { cn } from "@/lib/utils";

export function Sparkline({
  points,
  className,
}: {
  points: PricePoint[];
  className?: string;
}) {
  if (points.length < 2) return null;

  const width = 160;
  const height = 36;
  const pad = 1;
  const values = points.map((p) => p.p);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(max - min, 0.01);

  const coords = points.map((point, i) => {
    const x = pad + (i / (points.length - 1)) * (width - pad * 2);
    const y = pad + (1 - (point.p - min) / span) * (height - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const up = values[values.length - 1]! >= values[0]!;
  const stroke = up ? "var(--color-sage)" : "var(--color-clay)";

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className={cn("h-9 w-40 overflow-visible", className)}
      aria-hidden
    >
      <polyline
        fill="none"
        stroke={stroke}
        strokeWidth="1.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        points={coords.join(" ")}
      />
    </svg>
  );
}
