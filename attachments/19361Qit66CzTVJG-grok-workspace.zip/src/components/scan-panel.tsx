import { useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Bookmark, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { DivergenceMeter } from "@/components/divergence-meter";
import { ThreadComposer } from "@/components/thread-composer";
import { formatUsd } from "@/lib/format";
import { topOutcomes } from "@/lib/polymarket";
import { scanEvent } from "@/lib/scan-api";
import { useDeskStore } from "@/lib/store";
import type { Brief, MarketEvent, ScanResult } from "@/lib/types";
import { cn } from "@/lib/utils";

const STAGES = [
  "Searching X for the last 48 hours",
  "Reading the tape against the book",
  "Scoring crowd vs. capital",
  "Drafting the thread",
];

function toBrief(event: MarketEvent, result: ScanResult): Brief {
  const lead = topOutcomes(event, 1)[0];
  return {
    ...result,
    eventId: event.id,
    eventTitle: event.title,
    slug: event.slug,
    leadingLabel: lead?.label ?? "",
    leadingPct: lead?.probability ?? 0,
    savedAt: new Date().toISOString(),
  };
}

export function ScanPanel({
  event,
  initial,
}: {
  event: MarketEvent;
  initial?: ScanResult | null;
}) {
  const saveBrief = useDeskStore((s) => s.saveBrief);
  const briefs = useDeskStore((s) => s.briefs);
  const saved = briefs.some((b) => b.eventId === event.id);
  const [result, setResult] = useState<ScanResult | null>(initial ?? null);
  const [stage, setStage] = useState(0);

  const outcomes = useMemo(
    () =>
      topOutcomes(event, 8).map((o) => ({
        label: o.label,
        probability: o.probability,
      })),
    [event],
  );

  const mutation = useMutation({
    mutationFn: async () => {
      const timer = window.setInterval(() => {
        setStage((s) => (s + 1) % STAGES.length);
      }, 2200);
      try {
        const response = await scanEvent({
          data: {
            eventId: event.id,
            title: event.title,
            slug: event.slug,
            description: event.description,
            volume24h: event.volume24h,
            endDate: event.endDate,
            outcomes,
          },
        });
        if (!response.ok) throw new Error(response.error);
        return response.result;
      } finally {
        window.clearInterval(timer);
      }
    },
    onSuccess: (scan) => {
      setResult(scan);
      toast.success("Scan complete");
    },
    onError: (err: Error) => {
      toast.error(err.message || "Scan failed");
    },
  });

  function persist() {
    if (!result) return;
    saveBrief(toBrief(event, result));
    toast.success("Brief saved on this device");
  }

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-widest text-subtle uppercase">
            Grok scan
          </p>
          <h3 className="mt-1 font-display text-2xl tracking-tight">
            Crowd vs. capital
          </h3>
        </div>
        <Button
          onClick={() => {
            setStage(0);
            mutation.mutate();
          }}
          disabled={mutation.isPending}
          className="min-w-40"
        >
          {mutation.isPending ? (
            <>
              <Loader2 className="animate-spin" />
              Scanning
            </>
          ) : result ? (
            "Rescan"
          ) : (
            "Scan X vs. book"
          )}
        </Button>
      </div>

      {mutation.isPending ? (
        <div className="mt-5 rounded-lg bg-raised px-4 py-8 text-center">
          <p className="shimmer-text text-sm">{STAGES[stage]}</p>
          <p className="mt-2 text-xs text-subtle">
            Live X search · {formatUsd(event.volume24h)} on the contract
          </p>
        </div>
      ) : null}

      {result && !mutation.isPending ? (
        <div className="mt-5 flex flex-col gap-6 animate-fade-up">
          <DivergenceMeter score={result.divergenceScore} label={result.label} />

          <div>
            <h4 className="font-display text-2xl leading-snug tracking-tight">
              {result.headline}
            </h4>
            <p className="mt-3 text-sm leading-relaxed text-muted">{result.thesis}</p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <ReadCard title="Crowd" body={result.crowdRead} />
            <ReadCard title="Capital" body={result.capitalRead} />
          </div>

          {result.catalysts.length ? (
            <div>
              <h5 className="text-xs font-medium tracking-widest text-subtle uppercase">
                Catalysts
              </h5>
              <ul className="mt-2 flex flex-col gap-1.5">
                {result.catalysts.map((c) => (
                  <li key={c} className="text-sm text-fg before:mr-2 before:text-subtle before:content-['–']">
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <p className="text-sm">
            <span className="text-subtle">Watch · </span>
            {result.watch}
          </p>

          <ThreadComposer tweets={result.thread} />

          <div>
            <h5 className="mb-2 text-xs font-medium tracking-widest text-subtle uppercase">
              Editorial memo
            </h5>
            <p className="text-sm leading-relaxed text-muted">{result.memo}</p>
          </div>

          {result.citations.length ? (
            <div>
              <h5 className="mb-2 text-xs font-medium tracking-widest text-subtle uppercase">
                Sources
              </h5>
              <ul className="flex flex-col gap-1">
                {result.citations.map((cite, i) => (
                  <li key={`${cite.source}-${i}`} className="text-xs text-muted">
                    {cite.url ? (
                      <a
                        href={cite.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-fg underline decoration-border-strong underline-offset-2 hover:text-sage"
                      >
                        {cite.source}
                      </a>
                    ) : (
                      <span className="text-fg">{cite.source}</span>
                    )}
                    {cite.note ? ` — ${cite.note}` : ""}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-subtle">
            <span>
              {result.model} · {new Date(result.scannedAt).toLocaleTimeString()}
            </span>
            <Button variant="outline" size="sm" onClick={persist}>
              <Bookmark className={cn(saved && "fill-current")} />
              {saved ? "Saved" : "Save brief"}
            </Button>
          </div>
        </div>
      ) : null}

      {!result && !mutation.isPending ? (
        <p className="mt-4 text-sm text-muted">
          Run a scan to pull live posts from X, score them against these odds, and
          draft a five-post thread you can copy.
        </p>
      ) : null}
    </section>
  );
}

function ReadCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-md bg-raised p-4">
      <p className="text-xs font-medium tracking-widest text-subtle uppercase">{title}</p>
      <p className="mt-2 text-sm leading-relaxed">{body}</p>
    </div>
  );
}
