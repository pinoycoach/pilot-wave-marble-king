import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, ExternalLink, TrendingDown, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { OutcomeBars } from "@/components/outcome-bars";
import { ScanPanel } from "@/components/scan-panel";
import { Sparkline } from "@/components/sparkline";
import { formatCents, formatEndDate, formatPct, formatRelChange, formatUsd } from "@/lib/format";
import { CATEGORY_LABEL } from "@/lib/labels";
import { fetchPriceHistory } from "@/lib/markets-api";
import { isYesNoGroup, leadingTokenId, primaryOutcome, topOutcomes } from "@/lib/polymarket";
import { useDeskStore } from "@/lib/store";
import type { MarketEvent, SubMarket } from "@/lib/types";
import { cn } from "@/lib/utils";

export function MarketDetail({
  event,
  onBack,
}: {
  event: MarketEvent;
  onBack: () => void;
}) {
  const [imgFailed, setImgFailed] = useState(false);
  const briefs = useDeskStore((s) => s.briefs);
  const saved = briefs.find((b) => b.eventId === event.id);
  const yesNo = isYesNoGroup(event.markets);
  const outcomes = topOutcomes(event, 8, yesNo ? "book" : "prob");
  const tokenId = leadingTokenId(event);

  const history = useQuery({
    queryKey: ["history", tokenId],
    queryFn: async () => {
      if (!tokenId) return [];
      const res = await fetchPriceHistory({ data: { tokenId } });
      return res.ok ? res.points : [];
    },
    enabled: Boolean(tokenId),
    staleTime: 120_000,
  });

  const extraMarkets = !yesNo && event.markets.length > 1 ? event.markets.slice(0, 8) : [];

  return (
    <article className="px-4 py-5 sm:px-8 sm:py-8">
      <div className="mb-5 flex items-center gap-2 lg:hidden">
        <Button variant="ghost" size="sm" onClick={onBack} className="pl-2">
          <ArrowLeft />
          Markets
        </Button>
      </div>

      <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
        {event.image && !imgFailed ? (
          <img
            src={event.image}
            alt=""
            onError={() => setImgFailed(true)}
            className="size-20 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
          />
        ) : (
          <div className="flex size-20 shrink-0 items-center justify-center rounded-md bg-raised text-xs tracking-widest text-subtle uppercase">
            {CATEGORY_LABEL[event.category]}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Badge>{CATEGORY_LABEL[event.category]}</Badge>
            <span className="text-xs text-muted">Ends {formatEndDate(event.endDate)}</span>
          </div>
          <h1 className="mt-2 font-display text-3xl leading-tight tracking-tight sm:text-4xl">
            {event.title}
          </h1>
          <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted">
            <span className="tabular-nums text-fg">{formatUsd(event.volume24h)} 24h</span>
            <span className="text-subtle">·</span>
            <span className="tabular-nums">{formatUsd(event.volume)} total vol</span>
            <span className="text-subtle">·</span>
            <span className="tabular-nums">{formatUsd(event.liquidity)} liquidity</span>
            <span className="text-subtle">·</span>
            <a
              href={event.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-fg hover:text-sage"
            >
              Polymarket
              <ExternalLink className="size-3.5" />
            </a>
          </div>
        </div>
        {history.data && history.data.length > 2 ? (
          <div className="hidden shrink-0 sm:block">
            <p className="mb-1 text-right text-xs text-subtle">Leading price</p>
            <Sparkline points={history.data} />
          </div>
        ) : null}
      </div>

      {event.tags.length ? (
        <div className="mt-4 flex flex-wrap gap-1.5">
          {event.tags.slice(0, 8).map((tag, i) => (
            <Badge key={`${tag}-${i}`} tone="muted" className="normal-case tracking-normal">
              {tag}
            </Badge>
          ))}
        </div>
      ) : null}

      <div className="mt-8">
        <h2 className="mb-3 flex items-center gap-2 text-xs font-medium tracking-widest text-subtle uppercase">
          Implied probability
          <span className="font-sans text-sage normal-case tracking-normal">live</span>
        </h2>
        {yesNo ? <BookTable markets={event.markets} /> : <OutcomeBars outcomes={outcomes} />}
      </div>

      {extraMarkets.length > 1 ? (
        <div className="mt-6">
          <h2 className="mb-3 text-xs font-medium tracking-widest text-subtle uppercase">
            Related contracts
          </h2>
          <ul className="divide-y divide-border rounded-md bg-raised px-3">
            {extraMarkets.map((market) => {
              const top = primaryOutcome(market);
              return (
                <li key={market.id} className="flex items-center justify-between gap-3 py-2.5">
                  <span className="min-w-0 truncate text-sm">
                    {market.groupTitle || market.question}
                  </span>
                  {top ? (
                    <span className="shrink-0 text-sm tabular-nums text-muted">
                      {formatPct(top.probability)}
                    </span>
                  ) : null}
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}

      {event.description ? (
        <details className="mt-6 group">
          <summary className="cursor-pointer text-sm text-muted hover:text-fg">
            Resolution rules
          </summary>
          <p className="mt-2 text-sm leading-relaxed whitespace-pre-wrap text-muted">
            {event.description}
          </p>
        </details>
      ) : null}

      <ScanPanel event={event} initial={saved ?? null} />
    </article>
  );
}

function BookTable({ markets }: { markets: SubMarket[] }) {
  return (
    <ul className="divide-y divide-border overflow-hidden rounded-md bg-surface shadow-[var(--shadow-border)]">
      {markets.map((market) => {
        const yes = primaryOutcome(market);
        if (!yes) return null;
        const pct = Math.max(0, Math.min(100, yes.probability * 100));
        const change = formatRelChange(market.change24h, yes.probability);
        const Icon = change?.dir === "up" ? TrendingUp : TrendingDown;
        return (
          <li key={market.id} className="px-3 py-3 sm:px-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">
                  {market.groupTitle || market.question}
                </p>
                <p className="mt-0.5 text-xs tabular-nums text-muted">
                  {formatUsd(market.volume)} vol
                </p>
              </div>
              <div className="shrink-0 text-right">
                <div className="flex items-baseline justify-end gap-2">
                  {change ? (
                    <span
                      className={cn(
                        "inline-flex items-center gap-0.5 text-xs tabular-nums",
                        change.dir === "up" ? "text-sage" : "text-clay",
                      )}
                    >
                      <Icon className="size-3" />
                      {change.text}
                    </span>
                  ) : null}
                  <span className="text-base font-medium tabular-nums">
                    {formatPct(yes.probability)}
                  </span>
                </div>
                <p className="mt-0.5 text-xs tabular-nums text-muted">
                  Yes {formatCents(yes.probability)}
                  <span className="text-subtle"> · </span>
                  No {formatCents(1 - yes.probability)}
                </p>
              </div>
            </div>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-raised">
              <div
                className={cn(
                  "h-full rounded-full transition-[width] duration-500 ease-[var(--ease-out)]",
                  yes.probability >= 0.5 ? "bg-sage" : "bg-fg/40",
                )}
                style={{ width: `${pct}%` }}
              />
            </div>
          </li>
        );
      })}
    </ul>
  );
}
