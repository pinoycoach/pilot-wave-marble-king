import { useEffect, useRef, useState } from "react";
import { TrendingDown, TrendingUp } from "lucide-react";
import { formatPct, formatRelChange } from "@/lib/format";
import type { Outcome } from "@/lib/types";
import { cn } from "@/lib/utils";

function useTickFlash(value: number) {
  const prev = useRef<number | null>(null);
  const [flash, setFlash] = useState<"up" | "down" | null>(null);

  useEffect(() => {
    const last = prev.current;
    prev.current = value;
    if (last == null || Math.abs(value - last) < 0.0005) return;
    setFlash(value > last ? "up" : "down");
    const id = window.setTimeout(() => setFlash(null), 900);
    return () => window.clearTimeout(id);
  }, [value]);

  return flash;
}

function LivePct({ value }: { value: number }) {
  const flash = useTickFlash(value);
  return (
    <span
      className={cn(
        "font-medium tabular-nums text-fg transition-colors duration-500 ease-[var(--ease-out)]",
        flash === "up" && "text-sage",
        flash === "down" && "text-clay",
      )}
    >
      {formatPct(value)}
    </span>
  );
}

function ChangeChip({ outcome }: { outcome: Outcome }) {
  const change = formatRelChange(outcome.change24h ?? null, outcome.probability);
  if (!change) return null;
  const Icon = change.dir === "up" ? TrendingUp : TrendingDown;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 text-xs tabular-nums",
        change.dir === "up" ? "text-sage" : "text-clay",
      )}
    >
      <Icon className="size-3" />
      {change.text}
    </span>
  );
}

export function OutcomeBars({
  outcomes,
  compact = false,
}: {
  outcomes: Outcome[];
  compact?: boolean;
}) {
  if (!outcomes.length) return null;

  return (
    <div className={cn("flex flex-col", compact ? "gap-1.5" : "gap-2.5")}>
      {outcomes.map((outcome, index) => {
        const pct = Math.max(0, Math.min(100, outcome.probability * 100));
        const dominant = outcome.probability >= 0.5;
        return (
          <div key={`${outcome.label}-${index}`} className="min-w-0">
            <div className="mb-1 flex items-baseline justify-between gap-3">
              <span
                className={cn(
                  "truncate text-sm",
                  compact ? "text-muted" : "text-fg",
                )}
              >
                {outcome.label}
              </span>
              <span className="flex shrink-0 items-baseline gap-1.5">
                {!compact ? <ChangeChip outcome={outcome} /> : null}
                <LivePct value={outcome.probability} />
              </span>
            </div>
            <div className="h-1 overflow-hidden rounded-full bg-raised">
              <div
                className={cn(
                  "h-full rounded-full transition-[width] duration-500 ease-[var(--ease-out)]",
                  dominant ? "bg-sage" : "bg-fg/40",
                )}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
