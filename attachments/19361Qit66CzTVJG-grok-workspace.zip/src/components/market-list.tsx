import { Star } from "lucide-react";
import { formatUsd } from "@/lib/format";
import { CATEGORY_LABEL } from "@/lib/labels";
import { topOutcomes } from "@/lib/polymarket";
import type { MarketEvent } from "@/lib/types";
import { cn } from "@/lib/utils";
import { OutcomeBars } from "@/components/outcome-bars";

export function MarketList({
  events,
  selectedId,
  watchlist,
  onSelect,
  onToggleWatch,
}: {
  events: MarketEvent[];
  selectedId: string | null;
  watchlist: string[];
  onSelect: (id: string) => void;
  onToggleWatch: (id: string) => void;
}) {
  if (!events.length) {
    return (
      <div className="px-4 py-16 text-center text-sm text-muted">
        No live markets match this filter.
      </div>
    );
  }

  return (
    <ul className="flex flex-col gap-2 p-3">
      {events.map((event, index) => {
        const selected = event.id === selectedId;
        const watched = watchlist.includes(event.id);
        const outcomes = topOutcomes(event, 3);
        return (
          <li key={event.id}>
            <button
              type="button"
              onClick={() => onSelect(event.id)}
              className={cn(
                "w-full rounded-lg p-3 text-left transition-[box-shadow,background-color] duration-150 ease-out",
                selected
                  ? "bg-raised shadow-[var(--shadow-border-hover)]"
                  : "bg-surface shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
              )}
            >
              <div className="flex items-start gap-3">
                <span className="w-6 shrink-0 text-xs tabular-nums text-subtle">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="text-sm leading-snug font-medium">{event.title}</h2>
                    <span
                      role="button"
                      tabIndex={0}
                      aria-label={watched ? "Remove from watchlist" : "Add to watchlist"}
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleWatch(event.id);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          e.stopPropagation();
                          onToggleWatch(event.id);
                        }
                      }}
                      className={cn(
                        "mt-0.5 shrink-0 after:absolute after:top-1/2 after:left-1/2 after:size-10 after:-translate-x-1/2 after:-translate-y-1/2",
                        "relative text-subtle hover:text-fg",
                        watched && "text-amber",
                      )}
                    >
                      <Star className={cn("size-3.5", watched && "fill-current")} />
                    </span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted">
                    <span className="uppercase tracking-wide">
                      {CATEGORY_LABEL[event.category]}
                    </span>
                    <span className="text-subtle">·</span>
                    <span className="tabular-nums">{formatUsd(event.volume24h)} 24h</span>
                  </div>
                  <div className="mt-3">
                    <OutcomeBars outcomes={outcomes} compact />
                  </div>
                </div>
              </div>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
