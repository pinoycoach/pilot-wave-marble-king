import { useState } from "react";
import { Check, Copy, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

async function copyText(text: string) {
  await navigator.clipboard.writeText(text);
}

export function ThreadComposer({ tweets }: { tweets: string[] }) {
  const [copied, setCopied] = useState<number | "all" | null>(null);

  async function copyOne(index: number) {
    await copyText(tweets[index] ?? "");
    setCopied(index);
    toast.success("Post copied");
    window.setTimeout(() => setCopied((c) => (c === index ? null : c)), 1400);
  }

  async function copyAll() {
    const block = tweets
      .map((tweet, i) => `${i + 1}/${tweets.length}\n${tweet}`)
      .join("\n\n");
    await copyText(block);
    setCopied("all");
    toast.success("Thread copied");
    window.setTimeout(() => setCopied((c) => (c === "all" ? null : c)), 1400);
  }

  const first = tweets[0] ?? "";
  const intent = `https://x.com/intent/tweet?text=${encodeURIComponent(first)}`;

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-xs font-medium tracking-widest text-subtle uppercase">
          Thread
        </h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={copyAll}>
            {copied === "all" ? <Check /> : <Copy />}
            Copy all
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <a href={intent} target="_blank" rel="noreferrer">
              <ExternalLink />
              Open X
            </a>
          </Button>
        </div>
      </div>

      <ol className="flex flex-col gap-2">
        {tweets.map((tweet, i) => {
          const over = tweet.length > 280;
          return (
            <li
              key={`${i}-${tweet.slice(0, 24)}`}
              className="rounded-md bg-raised p-3"
            >
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-xs tabular-nums text-subtle">
                  {i + 1}/{tweets.length}
                </span>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "text-xs tabular-nums",
                      over ? "text-clay" : "text-subtle",
                    )}
                  >
                    {tweet.length}/280
                  </span>
                  <button
                    type="button"
                    onClick={() => copyOne(i)}
                    className="text-muted hover:text-fg"
                    aria-label={`Copy post ${i + 1}`}
                  >
                    {copied === i ? (
                      <Check className="size-3.5" />
                    ) : (
                      <Copy className="size-3.5" />
                    )}
                  </button>
                </div>
              </div>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{tweet}</p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
