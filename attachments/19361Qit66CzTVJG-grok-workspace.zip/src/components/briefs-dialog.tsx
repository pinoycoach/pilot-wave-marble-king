import { Bookmark } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatPct, relativeTime } from "@/lib/format";
import { SCAN_COPY } from "@/lib/labels";
import { useDeskStore } from "@/lib/store";

export function BriefsDialog({
  onOpenEvent,
}: {
  onOpenEvent: (eventId: string) => void;
}) {
  const briefs = useDeskStore((s) => s.briefs);
  const removeBrief = useDeskStore((s) => s.removeBrief);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bookmark className="size-4" />
          <span className="hidden sm:inline">Briefs</span>
          {briefs.length ? (
            <span className="ml-1 tabular-nums text-sage">{briefs.length}</span>
          ) : null}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogTitle>Saved briefs</DialogTitle>
        <DialogDescription>
          Stored on this device. Copy the thread from a market after reopening it.
        </DialogDescription>
        <div className="desk-scroll mt-4 flex-1 overflow-y-auto pr-1">
          {briefs.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted">
              Scan a market, then save the brief.
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {briefs.map((brief) => {
                const copy = SCAN_COPY[brief.label];
                return (
                  <li key={brief.eventId} className="rounded-md bg-raised p-3">
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        className="min-w-0 text-left"
                        onClick={() => onOpenEvent(brief.eventId)}
                      >
                        <p className="truncate text-sm font-medium">{brief.eventTitle}</p>
                        <p className="mt-1 line-clamp-2 text-xs text-muted">{brief.headline}</p>
                      </button>
                      <Badge tone={copy.tone}>{copy.title}</Badge>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-xs text-subtle">
                      <span className="tabular-nums">
                        {brief.leadingLabel} {formatPct(brief.leadingPct)} ·{" "}
                        {relativeTime(brief.savedAt || brief.scannedAt)}
                      </span>
                      <button
                        type="button"
                        className="hover:text-clay"
                        onClick={() => removeBrief(brief.eventId)}
                      >
                        Remove
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
