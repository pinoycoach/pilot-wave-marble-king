import { SCAN_COPY } from "@/lib/labels";
import type { ScanLabel } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export function DivergenceMeter({
  score,
  label,
}: {
  score: number;
  label: ScanLabel;
}) {
  const clamped = Math.max(0, Math.min(100, score));
  const copy = SCAN_COPY[label];

  return (
    <div className="rounded-lg bg-raised p-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-widest text-subtle uppercase">
            Divergence
          </p>
          <p className="mt-1 font-display text-5xl leading-none tracking-tight tabular-nums">
            {Math.round(clamped)}
          </p>
        </div>
        <Badge tone={copy.tone}>{copy.title}</Badge>
      </div>
      <p className="mt-3 text-sm text-muted">{copy.blurb}</p>

      <div className="relative mt-5">
        <div className="flex h-1.5 overflow-hidden rounded-full bg-bg">
          <div className="w-1/2 bg-sage/35" />
          <div className="w-1/2 bg-clay/35" />
        </div>
        <div
          className="absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg shadow-[var(--shadow-border)] transition-[left] duration-500 ease-[var(--ease-out)]"
          style={{ left: `${clamped}%` }}
        />
        <div className="mt-2 flex justify-between text-xs text-subtle">
          <span>Capital leads</span>
          <span>Aligned</span>
          <span>Crowd leads</span>
        </div>
      </div>
    </div>
  );
}
