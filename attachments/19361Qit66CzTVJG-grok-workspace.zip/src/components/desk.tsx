import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RefreshCw, Search } from "lucide-react";
import { Toaster } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { BriefsDialog } from "@/components/briefs-dialog";
import { MarketDetail } from "@/components/market-detail";
import { MarketList } from "@/components/market-list";
import { clockNow, formatUsd, relativeTime } from "@/lib/format";
import { useHydrated } from "@/lib/hydrate";
import { CATEGORY_LABEL } from "@/lib/labels";
import { collectTokenIds, overlayEvent } from "@/lib/live-tape";
import { listMarkets } from "@/lib/markets-api";
import { useDeskStore } from "@/lib/store";
import type { Category, MarketEvent } from "@/lib/types";
import { CATEGORIES } from "@/lib/types";
import { useLiveTape } from "@/lib/use-live-tape";
import { cn } from "@/lib/utils";

type SortKey = "volume" | "tossup" | "watched";

export function Desk({ initialEvents = [] }: { initialEvents?: MarketEvent[] }) {
  const hydrated = useHydrated();
  const watchlist = useDeskStore((s) => s.watchlist);
  const toggleWatch = useDeskStore((s) => s.toggleWatch);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState<Category>("all");
  const [sort, setSort] = useState<SortKey>("volume");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [clock, setClock] = useState("");
  const [desktop, setDesktop] = useState<boolean | null>(null);

  useEffect(() => {
    void useDeskStore.persist.rehydrate();
  }, []);

  useEffect(() => {
    setClock(clockNow());
    const id = window.setInterval(() => setClock(clockNow()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const media = window.matchMedia("(min-width: 1024px)");
    const apply = () => setDesktop(media.matches);
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    const id = window.setTimeout(() => setDebounced(query.trim()), 400);
    return () => window.clearTimeout(id);
  }, [query]);

  const markets = useQuery({
    queryKey: ["markets", debounced],
    queryFn: async () => {
      const res = await listMarkets({ data: { q: debounced } });
      if (!res.ok) throw new Error(res.error);
      return res.events;
    },
    initialData: debounced ? undefined : initialEvents.length ? initialEvents : undefined,
    staleTime: 40_000,
    refetchInterval: 90_000,
  });

  const snapshot = markets.data ?? [];
  const tokenIds = useMemo(
    () => collectTokenIds(snapshot, selectedId),
    [snapshot, selectedId],
  );
  const tape = useLiveTape(hydrated ? tokenIds : []);
  const events = useMemo(
    () => snapshot.map((event) => overlayEvent(event, tape.ticks)),
    [snapshot, tape.ticks],
  );

  const filtered = useMemo(() => {
    let next = events;
    if (category !== "all") {
      next = next.filter((event) => event.category === category);
    }
    if (sort === "watched") {
      next = next.filter((event) => watchlist.includes(event.id));
    } else if (sort === "tossup") {
      next = [...next].sort((a, b) => b.competitive - a.competitive);
    }
    return next;
  }, [events, category, sort, watchlist]);

  useEffect(() => {
    if (desktop !== true) return;
    if (selectedId || !filtered[0]) return;
    setSelectedId(filtered[0].id);
  }, [desktop, filtered, selectedId]);

  const selected: MarketEvent | undefined =
    filtered.find((e) => e.id === selectedId) ??
    events.find((e) => e.id === selectedId);

  const showList = desktop !== false || !selectedId;
  const showDetail = desktop !== false || Boolean(selectedId);
  const volume24 = events.reduce((sum, e) => sum + e.volume24h, 0);
  const fetchedAt = markets.dataUpdatedAt ? new Date(markets.dataUpdatedAt) : null;
  const tapeLabel =
    tape.status === "live"
      ? "LIVE tape"
      : tape.status === "polling"
        ? "Polling book"
        : tape.status === "connecting"
          ? "Connecting tape"
          : "Book snapshot";

  function openEvent(id: string) {
    setSelectedId(id);
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="sticky top-0 z-20 border-b border-border bg-bg px-4 py-3 sm:px-6">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-widest text-subtle uppercase">
              Prediction desk
            </p>
            <div className="flex items-baseline gap-3">
              <h1 className="font-display text-3xl tracking-tight italic sm:text-4xl">
                Diverge
              </h1>
              <span className="hidden text-xs text-muted sm:inline">
                Capital vs. crowd
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <div className="hidden items-center gap-2 pr-2 text-xs text-muted md:flex">
              <span
                className={cn(
                  "live-dot size-1.5 rounded-full",
                  tape.status === "live"
                    ? "bg-sage"
                    : tape.status === "polling"
                      ? "bg-amber"
                      : "bg-subtle",
                )}
              />
              {clock ? <span className="tabular-nums">{clock}</span> : <span className="tabular-nums">--:--:--</span>}
            </div>
            <BriefsDialog
              onOpenEvent={(id) => {
                setSelectedId(id);
              }}
            />
            <Button
              variant="ghost"
              size="icon"
              aria-label="Refresh markets"
              onClick={() => markets.refetch()}
              disabled={markets.isFetching}
            >
              <RefreshCw className={cn("size-4", markets.isFetching && "animate-spin")} />
            </Button>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
          <span className="inline-flex items-center gap-1.5 text-fg">
            <span
              className={cn(
                "live-dot size-1.5 rounded-full",
                tape.status === "live" ? "bg-sage" : tape.status === "polling" ? "bg-amber" : "bg-subtle",
              )}
            />
            <span className="uppercase tracking-wide">{tapeLabel}</span>
          </span>
          {hydrated && tape.lastTickAt ? (
            <>
              <span className="text-subtle">·</span>
              <span>print {relativeTime(tape.lastTickAt)}</span>
            </>
          ) : null}
          <span className="text-subtle">·</span>
          <span className="tabular-nums text-fg">{formatUsd(volume24)} 24h</span>
          <span className="text-subtle">·</span>
          <span className="tabular-nums">{events.length} live markets</span>
          {hydrated && fetchedAt ? (
            <>
              <span className="text-subtle">·</span>
              <span>catalog {relativeTime(fetchedAt)}</span>
            </>
          ) : null}
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <aside
          className={cn(
            "flex min-h-0 flex-col border-border lg:w-96 lg:shrink-0 lg:border-r",
            showList ? "flex" : "hidden lg:flex",
          )}
        >
          <div className="border-b border-border p-3">
            <label className="relative block">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search markets"
                className="pl-9"
                aria-label="Search markets"
              />
            </label>
            <div className="desk-scroll mt-3 flex gap-1.5 overflow-x-auto pb-1">
              {CATEGORIES.map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setCategory(id)}
                  className={cn(
                    "h-9 shrink-0 rounded-full px-3 text-xs tracking-wide uppercase",
                    category === id
                      ? "bg-fg text-accent-fg"
                      : "bg-raised text-muted hover:text-fg",
                  )}
                >
                  {CATEGORY_LABEL[id]}
                </button>
              ))}
            </div>
            <div className="mt-3 flex gap-1">
              {(
                [
                  ["volume", "Volume"],
                  ["tossup", "Toss-up"],
                  ["watched", "Watched"],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSort(key)}
                  className={cn(
                    "h-8 rounded-full px-3 text-xs",
                    sort === key ? "bg-raised text-fg" : "text-subtle hover:text-fg",
                  )}
                >
                  {label}
                  {key === "watched" && hydrated && watchlist.length ? (
                    <span className="ml-1 tabular-nums text-sage">{watchlist.length}</span>
                  ) : null}
                </button>
              ))}
            </div>
          </div>

          <div className="desk-scroll min-h-0 flex-1 overflow-y-auto">
            {markets.isLoading ? (
              <div className="flex flex-col gap-2 p-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-28 rounded-lg" />
                ))}
              </div>
            ) : markets.isError ? (
              <div className="px-4 py-16 text-center">
                <p className="text-sm text-muted">
                  {markets.error instanceof Error
                    ? markets.error.message
                    : "Could not load Polymarket."}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => markets.refetch()}
                >
                  Try again
                </Button>
              </div>
            ) : (
              <MarketList
                events={filtered}
                selectedId={selectedId}
                watchlist={hydrated ? watchlist : []}
                onSelect={openEvent}
                onToggleWatch={toggleWatch}
              />
            )}
          </div>
        </aside>

        <section
          className={cn(
            "desk-scroll min-h-0 flex-1 overflow-y-auto",
            showDetail ? "block" : "hidden lg:block",
          )}
        >
          {selected ? (
            <MarketDetail
              key={selected.id}
              event={selected}
              onBack={() => setSelectedId(null)}
            />
          ) : (
            <EmptyDesk loading={markets.isLoading} />
          )}
        </section>
      </div>

      <Toaster
        theme="dark"
        position="bottom-right"
        toastOptions={{
          style: {
            background: "var(--color-surface)",
            color: "var(--color-fg)",
            border: "1px solid var(--color-border)",
          },
        }}
      />
    </div>
  );
}

function EmptyDesk({ loading }: { loading: boolean }) {
  return (
    <div className="flex h-full min-h-80 flex-col items-center justify-center px-6 text-center">
      <Badge tone="sage">Live</Badge>
      <p className="mt-4 font-display text-3xl tracking-tight">
        {loading ? "Opening the book" : "Pick a market"}
      </p>
      <p className="mt-2 max-w-sm text-sm text-muted">
        Live Polymarket odds on the left. Scan any contract against X to see where
        the crowd and the capital disagree.
      </p>
    </div>
  );
}
