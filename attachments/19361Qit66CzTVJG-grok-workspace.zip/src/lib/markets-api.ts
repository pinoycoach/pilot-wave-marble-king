import { createServerFn } from "@tanstack/react-start";
import { normalizeEvent } from "./polymarket";
import type { MarketEvent, PricePoint } from "./types";

const GAMMA = "https://gamma-api.polymarket.com";
const CLOB = "https://clob.polymarket.com";
const UA = "DivergeDesk/1.0 (prediction desk; +https://grok.com)";

type CacheEntry<T> = { at: number; value: T };
const listCache = new Map<string, CacheEntry<MarketEvent[]>>();
const LIST_TTL = 45_000;

async function gammaGet(path: string): Promise<unknown> {
  const res = await fetch(`${GAMMA}${path}`, {
    headers: { Accept: "application/json", "User-Agent": UA },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) throw new Error(`Polymarket ${res.status}`);
  return res.json();
}

function asEvents(payload: unknown): unknown[] {
  if (Array.isArray(payload)) return payload;
  if (payload && typeof payload === "object") {
    const rec = payload as Record<string, unknown>;
    if (Array.isArray(rec.events)) return rec.events;
    if (Array.isArray(rec.data)) return rec.data;
  }
  return [];
}

async function loadEvents(query: string): Promise<MarketEvent[]> {
  const q = query.trim();
  const key = q ? `q:${q.toLowerCase()}` : "top";
  const hit = listCache.get(key);
  if (hit && Date.now() - hit.at < LIST_TTL) return hit.value;

  const raw = q
    ? await gammaGet(`/public-search?q=${encodeURIComponent(q)}&limit=40`)
    : await gammaGet(
        "/events?active=true&closed=false&order=volume24hr&ascending=false&limit=40",
      );

  const events = asEvents(raw)
    .map(normalizeEvent)
    .filter((event): event is MarketEvent => Boolean(event))
    .sort((a, b) => b.volume24h - a.volume24h);

  listCache.set(key, { at: Date.now(), value: events });
  return events;
}

export const listMarkets = createServerFn({ method: "POST" })
  .validator((input: { q?: string }) => input ?? {})
  .handler(async ({ data }): Promise<{ ok: true; events: MarketEvent[] } | { ok: false; error: string }> => {
    try {
      const events = await loadEvents(data.q ?? "");
      return { ok: true, events };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : "Could not load markets",
      };
    }
  });

export const fetchPriceHistory = createServerFn({ method: "POST" })
  .validator((input: { tokenId: string }) => input)
  .handler(async ({ data }): Promise<{ ok: true; points: PricePoint[] } | { ok: false; error: string }> => {
    try {
      const url = `${CLOB}/prices-history?market=${encodeURIComponent(data.tokenId)}&interval=1d&fidelity=60`;
      const res = await fetch(url, {
        headers: { Accept: "application/json", "User-Agent": UA },
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) return { ok: false, error: `History ${res.status}` };
      const body = (await res.json()) as { history?: { t: number; p: number }[] };
      const points = (body.history ?? [])
        .filter((row) => Number.isFinite(row.t) && Number.isFinite(row.p))
        .map((row) => ({ t: row.t, p: row.p }));
      return { ok: true, points };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : "No history",
      };
    }
  });

async function midpointFor(tokenId: string): Promise<number | null> {
  const res = await fetch(`${CLOB}/midpoint?token_id=${encodeURIComponent(tokenId)}`, {
    headers: { Accept: "application/json", "User-Agent": UA },
    signal: AbortSignal.timeout(6_000),
  });
  if (!res.ok) return null;
  const body = (await res.json()) as { mid?: unknown };
  const n = typeof body.mid === "number" ? body.mid : Number(body.mid);
  return Number.isFinite(n) ? n : null;
}

export const fetchMidpoints = createServerFn({ method: "POST" })
  .validator((input: { tokenIds: string[] }) => input)
  .handler(async ({ data }): Promise<{ ok: true; prices: Record<string, number> } | { ok: false; error: string }> => {
    const tokenIds = [...new Set(data.tokenIds.filter(Boolean))].slice(0, 32);
    const prices: Record<string, number> = {};
    const chunk = 8;
    try {
      for (let i = 0; i < tokenIds.length; i += chunk) {
        const slice = tokenIds.slice(i, i + chunk);
        const rows = await Promise.all(
          slice.map(async (id) => {
            const mid = await midpointFor(id);
            return mid == null ? null : ([id, mid] as const);
          }),
        );
        for (const row of rows) {
          if (row) prices[row[0]] = row[1];
        }
      }
      return { ok: true, prices };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : "No live prices",
      };
    }
  });
