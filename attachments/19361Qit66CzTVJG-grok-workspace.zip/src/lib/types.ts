export const CATEGORIES = [
  "all",
  "politics",
  "finance",
  "sports",
  "crypto",
  "world",
  "culture",
] as const;

export type Category = (typeof CATEGORIES)[number];

export type Outcome = {
  label: string;
  probability: number;
  tokenId: string | null;
  change24h?: number | null;
  volume?: number;
};

export type SubMarket = {
  id: string;
  question: string;
  slug: string;
  groupTitle: string;
  volume: number;
  volume24h: number;
  change24h: number | null;
  outcomes: Outcome[];
};

export type MarketEvent = {
  id: string;
  title: string;
  slug: string;
  url: string;
  description: string;
  image: string | null;
  volume24h: number;
  volume: number;
  liquidity: number;
  endDate: string | null;
  tags: string[];
  category: Exclude<Category, "all"> | "other";
  markets: SubMarket[];
  leading: Outcome | null;
  competitive: number;
};

export type ScanLabel = "overhyped" | "under_radar" | "consensus" | "contested";

export type ScanCitation = {
  source: string;
  url?: string;
  note: string;
};

export type ScanResult = {
  divergenceScore: number;
  label: ScanLabel;
  headline: string;
  thesis: string;
  crowdRead: string;
  capitalRead: string;
  catalysts: string[];
  watch: string;
  citations: ScanCitation[];
  thread: string[];
  memo: string;
  scannedAt: string;
  model: string;
};

export type Brief = ScanResult & {
  eventId: string;
  eventTitle: string;
  slug: string;
  leadingLabel: string;
  leadingPct: number;
  savedAt: string;
};


export type PricePoint = { t: number; p: number };
