import type { Category, ScanLabel } from "./types";

export const CATEGORY_LABEL: Record<Category | "other", string> = {
  all: "All",
  politics: "Politics",
  finance: "Finance",
  sports: "Sports",
  crypto: "Crypto",
  world: "World",
  culture: "Culture",
  other: "Other",
};

export const SCAN_COPY: Record<
  ScanLabel,
  { title: string; tone: "sage" | "clay" | "amber" | "muted"; blurb: string }
> = {
  overhyped: {
    title: "Overhyped",
    tone: "clay",
    blurb: "The timeline is louder than the book.",
  },
  under_radar: {
    title: "Under the radar",
    tone: "sage",
    blurb: "Capital is priced. The crowd has not noticed.",
  },
  consensus: {
    title: "Consensus",
    tone: "muted",
    blurb: "Odds and narrative are walking in step.",
  },
  contested: {
    title: "Contested",
    tone: "amber",
    blurb: "A coin-flip in the book, a fight on the timeline.",
  },
};
