import { topOutcomes } from "./polymarket";
import type { MarketEvent } from "./types";

export const CLOB_MARKET_WS = "wss://ws-subscriptions-clob.polymarket.com/ws/market";

export type TapeStatus = "idle" | "connecting" | "live" | "polling";

export type LiveTick = {
  tokenId: string;
  bid: number | null;
  ask: number | null;
  last: number | null;
  at: number;
};

function num(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function clampProb(value: number): number {
  return Math.min(1, Math.max(0, value));
}

/** Tight book → midpoint. Wide book (illiquid Yes tokens) → last print, never 50/50. */
export function impliedPrice(tick: LiveTick): number | null {
  const { bid, ask, last } = tick;
  if (bid != null && ask != null && ask >= bid && ask - bid <= 0.08) {
    return clampProb((bid + ask) / 2);
  }
  if (last != null) return clampProb(last);
  return null;
}

function bestLevel(
  levels: unknown,
  pick: "max" | "min",
): number | null {
  if (!Array.isArray(levels) || !levels.length) return null;
  let best: number | null = null;
  for (const row of levels) {
    if (!row || typeof row !== "object") continue;
    const price = num((row as { price?: unknown }).price);
    if (price == null) continue;
    if (best == null) best = price;
    else best = pick === "max" ? Math.max(best, price) : Math.min(best, price);
  }
  return best;
}

export function mergeTick(prev: LiveTick | undefined, patch: Partial<LiveTick> & { tokenId: string }): LiveTick {
  return {
    tokenId: patch.tokenId,
    bid: patch.bid !== undefined ? patch.bid : (prev?.bid ?? null),
    ask: patch.ask !== undefined ? patch.ask : (prev?.ask ?? null),
    last: patch.last !== undefined ? patch.last : (prev?.last ?? null),
    at: patch.at ?? Date.now(),
  };
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function ticksFromEvent(raw: unknown, at: number): LiveTick[] {
  const rec = asRecord(raw);
  if (!rec) return [];

  const type = typeof rec.event_type === "string" ? rec.event_type : "";

  if (type === "price_change" && Array.isArray(rec.price_changes)) {
    const out: LiveTick[] = [];
    for (const change of rec.price_changes) {
      const row = asRecord(change);
      if (!row) continue;
      const tokenId = typeof row.asset_id === "string" ? row.asset_id : "";
      if (!tokenId) continue;
      out.push({
        tokenId,
        bid: num(row.best_bid),
        ask: num(row.best_ask),
        last: null,
        at,
      });
    }
    return out;
  }

  const tokenId = typeof rec.asset_id === "string" ? rec.asset_id : "";
  if (!tokenId) return [];

  if (type === "last_trade_price") {
    return [{ tokenId, bid: null, ask: null, last: num(rec.price), at }];
  }

  if (type === "best_bid_ask") {
    return [{ tokenId, bid: num(rec.best_bid), ask: num(rec.best_ask), last: null, at }];
  }

  if (type === "book" || Array.isArray(rec.bids) || Array.isArray(rec.asks)) {
    return [
      {
        tokenId,
        bid: bestLevel(rec.bids, "max"),
        ask: bestLevel(rec.asks, "min"),
        last: num(rec.last_trade_price),
        at,
      },
    ];
  }

  return [];
}

export function parseTapeFrame(raw: string, at = Date.now()): LiveTick[] {
  const text = raw.trim();
  if (!text || text === "PONG" || text === "PING") return [];
  let payload: unknown;
  try {
    payload = JSON.parse(text);
  } catch {
    return [];
  }
  const items = Array.isArray(payload) ? payload : [payload];
  const ticks: LiveTick[] = [];
  for (const item of items) {
    ticks.push(...ticksFromEvent(item, at));
  }
  return ticks.filter((tick) => tick.bid != null || tick.ask != null || tick.last != null);
}

export function collectTokenIds(events: MarketEvent[], selectedId: string | null, limit = 80): string[] {
  const ids: string[] = [];
  const seen = new Set<string>();

  function add(tokenId: string | null | undefined) {
    if (!tokenId || seen.has(tokenId)) return;
    seen.add(tokenId);
    ids.push(tokenId);
  }

  for (const event of events) {
    for (const outcome of topOutcomes(event, 3)) add(outcome.tokenId);
  }

  const selected = events.find((event) => event.id === selectedId);
  if (selected) {
    for (const market of selected.markets) {
      for (const outcome of market.outcomes) add(outcome.tokenId);
    }
  }

  return ids.slice(0, limit);
}

export function overlayEvent(event: MarketEvent, ticks: Record<string, LiveTick>): MarketEvent {
  let changed = false;
  const markets = event.markets.map((market) => {
    let marketChanged = false;
    const outcomes = market.outcomes.map((outcome) => {
      if (!outcome.tokenId) return outcome;
      const tick = ticks[outcome.tokenId];
      if (!tick) return outcome;
      const next = impliedPrice(tick);
      if (next == null || Math.abs(next - outcome.probability) < 0.00005) return outcome;
      marketChanged = true;
      changed = true;
      return { ...outcome, probability: next };
    });
    return marketChanged ? { ...market, outcomes } : market;
  });

  if (!changed) return event;
  const next: MarketEvent = { ...event, markets, leading: null, competitive: 0 };
  const leading = topOutcomes(next, 1)[0] ?? null;
  next.leading = leading;
  next.competitive = 1 - Math.abs((leading?.probability ?? 0.5) - 0.5) * 2;
  return next;
}
