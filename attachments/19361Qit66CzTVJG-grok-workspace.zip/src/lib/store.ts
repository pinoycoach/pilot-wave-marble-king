import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Brief } from "./types";

type DeskState = {
  watchlist: string[];
  briefs: Brief[];
  toggleWatch: (id: string) => void;
  saveBrief: (brief: Brief) => void;
  removeBrief: (eventId: string) => void;
};

export const useDeskStore = create<DeskState>()(
  persist(
    (set, get) => ({
      watchlist: [],
      briefs: [],
      toggleWatch: (id) => {
        const current = get().watchlist;
        set({
          watchlist: current.includes(id) ? current.filter((x) => x !== id) : [id, ...current],
        });
      },
      saveBrief: (brief) => {
        set({
          briefs: [brief, ...get().briefs.filter((b) => b.eventId !== brief.eventId)].slice(0, 40),
        });
      },
      removeBrief: (eventId) => {
        set({ briefs: get().briefs.filter((b) => b.eventId !== eventId) });
      },
    }),
    { name: "diverge-desk", skipHydration: true },
  ),
);
