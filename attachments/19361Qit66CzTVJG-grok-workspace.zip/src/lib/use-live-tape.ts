import { useEffect, useMemo, useRef, useState } from "react";
import { fetchMidpoints } from "./markets-api";
import {
  CLOB_MARKET_WS,
  mergeTick,
  parseTapeFrame,
  type LiveTick,
  type TapeStatus,
} from "./live-tape";

const PING_MS = 10_000;
const FLUSH_MS = 200;
const FALLBACK_MS = 4_000;
const RECONNECT_MAX = 12_000;

export function useLiveTape(tokenIds: string[]) {
  const [ticks, setTicks] = useState<Record<string, LiveTick>>({});
  const [status, setStatus] = useState<TapeStatus>("idle");
  const [lastTickAt, setLastTickAt] = useState<number | null>(null);

  const ticksRef = useRef(ticks);
  ticksRef.current = ticks;
  const pendingRef = useRef(new Map<string, LiveTick>());
  const flushTimer = useRef<number | null>(null);
  const liveRef = useRef(false);
  const socketRef = useRef<WebSocket | null>(null);
  const subscribedRef = useRef(new Set<string>());
  const idsRef = useRef<string[]>([]);

  const idsKey = tokenIds.join("|");
  const ids = useMemo(() => (idsKey ? idsKey.split("|") : []), [idsKey]);
  idsRef.current = ids;

  function flushSoon() {
    if (flushTimer.current != null) return;
    flushTimer.current = window.setTimeout(() => {
      flushTimer.current = null;
      const batch = pendingRef.current;
      if (!batch.size) return;
      pendingRef.current = new Map();
      setTicks((current) => {
        const next = { ...current };
        for (const [id, tick] of batch) next[id] = tick;
        return next;
      });
      setLastTickAt(Date.now());
    }, FLUSH_MS);
  }

  function applyTicks(incoming: LiveTick[]) {
    if (!incoming.length) return;
    for (const tick of incoming) {
      const prev = pendingRef.current.get(tick.tokenId) ?? ticksRef.current[tick.tokenId];
      pendingRef.current.set(tick.tokenId, mergeTick(prev, tick));
    }
    flushSoon();
  }

  const applyRef = useRef(applyTicks);
  applyRef.current = applyTicks;

  useEffect(() => {
    if (typeof WebSocket === "undefined") {
      liveRef.current = false;
      setStatus("idle");
      return;
    }
    if (!idsKey) {
      liveRef.current = false;
      setStatus("idle");
      return;
    }

    let closed = false;
    let ping: number | null = null;
    let reconnect: number | null = null;
    let attempt = 0;

    function subscribe(ws: WebSocket, nextIds: string[]) {
      if (ws.readyState !== WebSocket.OPEN) return;
      const subscribed = subscribedRef.current;
      const next = new Set(nextIds);
      const drop = [...subscribed].filter((id) => !next.has(id));
      if (drop.length) {
        ws.send(JSON.stringify({ assets_ids: drop, operation: "unsubscribe" }));
        for (const id of drop) subscribed.delete(id);
      }
      ws.send(
        JSON.stringify({
          assets_ids: nextIds,
          type: "market",
          custom_feature_enabled: true,
        }),
      );
      subscribed.clear();
      for (const id of nextIds) subscribed.add(id);
    }

    function connect() {
      if (closed) return;
      liveRef.current = false;
      setStatus((current) => (current === "polling" ? "polling" : "connecting"));
      const ws = new WebSocket(CLOB_MARKET_WS);
      socketRef.current = ws;

      ws.addEventListener("open", () => {
        if (closed || socketRef.current !== ws) return;
        attempt = 0;
        liveRef.current = true;
        setStatus("live");
        subscribe(ws, idsRef.current);
        ping = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) ws.send("PING");
        }, PING_MS);
      });

      ws.addEventListener("message", (event) => {
        if (closed || socketRef.current !== ws) return;
        const raw = typeof event.data === "string" ? event.data : "";
        if (!raw) return;
        applyRef.current(parseTapeFrame(raw));
      });

      ws.addEventListener("close", () => {
        if (socketRef.current === ws) socketRef.current = null;
        liveRef.current = false;
        subscribedRef.current.clear();
        if (ping != null) window.clearInterval(ping);
        ping = null;
        if (closed) return;
        setStatus("polling");
        const wait = Math.min(RECONNECT_MAX, 800 * 2 ** attempt);
        attempt += 1;
        reconnect = window.setTimeout(connect, wait);
      });

      ws.addEventListener("error", () => {
        try {
          ws.close();
        } catch {
          /* ignore */
        }
      });
    }

    connect();

    return () => {
      closed = true;
      liveRef.current = false;
      if (ping != null) window.clearInterval(ping);
      if (reconnect != null) window.clearTimeout(reconnect);
      try {
        socketRef.current?.close();
      } catch {
        /* ignore */
      }
      socketRef.current = null;
      subscribedRef.current.clear();
    };
  }, [idsKey ? "on" : "off"]);

  useEffect(() => {
    const ws = socketRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN || !ids.length) return;
    ws.send(
      JSON.stringify({
        assets_ids: ids,
        type: "market",
        custom_feature_enabled: true,
      }),
    );
    subscribedRef.current = new Set(ids);
  }, [ids, idsKey]);

  useEffect(() => {
    if (!ids.length) return;

    let cancelled = false;
    let timer: number | null = null;

    async function poll() {
      if (cancelled) return;
      if (liveRef.current) {
        timer = window.setTimeout(poll, FALLBACK_MS);
        return;
      }
      setStatus((current) => (current === "live" ? current : "polling"));
      try {
        const res = await fetchMidpoints({ data: { tokenIds: idsRef.current } });
        if (!cancelled && res.ok) {
          const at = Date.now();
          applyRef.current(
            Object.entries(res.prices).map(([tokenId, last]) => ({
              tokenId,
              bid: null,
              ask: null,
              last,
              at,
            })),
          );
        }
      } catch {
        /* keep last snapshot */
      }
      if (!cancelled) timer = window.setTimeout(poll, FALLBACK_MS);
    }

    const start = window.setTimeout(poll, 2_500);

    return () => {
      cancelled = true;
      window.clearTimeout(start);
      if (timer != null) window.clearTimeout(timer);
    };
  }, [idsKey]);

  useEffect(() => {
    return () => {
      if (flushTimer.current != null) window.clearTimeout(flushTimer.current);
    };
  }, []);

  return { ticks, status, lastTickAt };
}
