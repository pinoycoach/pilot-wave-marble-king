export function formatUsd(value: number): string {
  const n = Number.isFinite(value) ? value : 0;
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1_000_000_000) return `${sign}$${(abs / 1_000_000_000).toFixed(1)}B`;
  if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 10_000) return `${sign}$${(abs / 1_000).toFixed(0)}K`;
  if (abs >= 1_000) return `${sign}$${(abs / 1_000).toFixed(1)}K`;
  return `${sign}$${abs.toFixed(0)}`;
}

export function formatPct(probability: number, digits?: number): string {
  const pct = (Number.isFinite(probability) ? probability : 0) * 100;
  const d = digits ?? (pct >= 99.5 || pct < 1 ? 1 : 0);
  return `${pct.toFixed(d)}%`;
}

export function formatCents(probability: number): string {
  const cents = (Number.isFinite(probability) ? probability : 0) * 100;
  if (cents < 10 || cents > 90) return `${Math.max(0, cents).toFixed(1)}¢`;
  return `${Math.round(cents)}¢`;
}

export function formatRelChange(delta: number | null | undefined, price: number): {
  text: string;
  dir: "up" | "down";
} | null {
  if (delta == null || !Number.isFinite(delta) || !Number.isFinite(price)) return null;
  if (Math.abs(delta) < 0.0005) return null;
  const prev = price - delta;
  if (Math.abs(prev) < 0.0005) return null;
  const rel = (delta / Math.abs(prev)) * 100;
  if (!Number.isFinite(rel) || Math.abs(rel) < 0.5) return null;
  return { text: `${Math.abs(rel).toFixed(0)}%`, dir: rel >= 0 ? "up" : "down" };
}

export function formatEndDate(iso: string | null): string {
  if (!iso) return "Open";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "Open";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: date.getFullYear() !== new Date().getFullYear() ? "numeric" : undefined,
  });
}

export function relativeTime(iso: string | number | Date): string {
  const date = iso instanceof Date ? iso : new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const diff = Date.now() - date.getTime();
  const sec = Math.round(diff / 1000);
  if (sec < 10) return "just now";
  if (sec < 60) return `${sec}s ago`;
  const min = Math.round(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  return `${day}d ago`;
}

export function clockNow(): string {
  return new Date().toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}
