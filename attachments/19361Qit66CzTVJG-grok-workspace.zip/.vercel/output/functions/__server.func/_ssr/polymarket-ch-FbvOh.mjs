//#region node_modules/.nitro/vite/services/ssr/assets/polymarket-ch-FbvOh.js
function num(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return n;
	}
	return 0;
}
function str(value) {
	return typeof value === "string" ? value : value == null ? "" : String(value);
}
function parseList(value) {
	if (Array.isArray(value)) return value.map((item) => str(item)).filter(Boolean);
	if (typeof value === "string" && value.trim()) try {
		const parsed = JSON.parse(value);
		if (Array.isArray(parsed)) return parsed.map((item) => str(item)).filter(Boolean);
	} catch {
		return [];
	}
	return [];
}
var CATEGORY_RULES = [
	{
		id: "finance",
		needles: [
			"fed",
			"economy",
			"inflation",
			"rates",
			"fomc",
			"cpi",
			"jobs report",
			"gdp",
			"recession",
			"stock",
			"powell",
			"treasury",
			"interest"
		]
	},
	{
		id: "sports",
		needles: [
			"sports",
			"nba",
			"nfl",
			"mlb",
			"nhl",
			"soccer",
			"fifa",
			"uefa",
			"ufc",
			"tennis",
			"cricket",
			"premier league",
			"formula",
			"march madness"
		]
	},
	{
		id: "crypto",
		needles: [
			"crypto",
			"bitcoin",
			"ethereum",
			"solana",
			"btc",
			"eth",
			"defi",
			"memecoin",
			"blockchain"
		]
	},
	{
		id: "world",
		needles: [
			"geopolitics",
			"war",
			"ukraine",
			"israel",
			"gaza",
			"nato",
			"iran",
			"russia",
			"ceasefire",
			"blockade"
		]
	},
	{
		id: "culture",
		needles: [
			"music",
			"movie",
			"oscar",
			"grammy",
			"celebrity",
			"pop culture",
			"album",
			"box office",
			"award",
			"entertainment",
			"film"
		]
	},
	{
		id: "politics",
		needles: [
			"politics",
			"election",
			"president",
			"trump",
			"biden",
			"harris",
			"congress",
			"senate",
			"democrat",
			"republican",
			"white house",
			"gop",
			"primary",
			"governor"
		]
	}
];
function classifyCategory(title, tags) {
	const hay = `${title} ${tags.join(" ")}`.toLowerCase();
	for (const rule of CATEGORY_RULES) if (rule.needles.some((needle) => hay.includes(needle))) return rule.id;
	return "other";
}
function mapOutcomes(raw) {
	const labels = parseList(raw.outcomes);
	const prices = parseList(raw.outcomePrices).map((p) => num(p));
	const tokens = parseList(raw.clobTokenIds);
	if (!labels.length) return [];
	const last = num(raw.lastTradePrice);
	const yesAt = labels.findIndex((label) => /^yes$/i.test(label));
	return labels.map((label, i) => {
		const listed = prices[i] ?? 0;
		return {
			label,
			probability: i === yesAt && last > 0 && Math.abs(last - listed) < .08 ? last : listed,
			tokenId: tokens[i] ?? null
		};
	});
}
function primaryOutcome(market) {
	const yes = market.outcomes.find((o) => /^yes$/i.test(o.label));
	if (yes) return yes;
	return [...market.outcomes].sort((a, b) => b.probability - a.probability)[0] ?? null;
}
function mapSubMarket(raw) {
	const id = str(raw.id);
	if (!id) return null;
	const change24h = num(raw.oneDayPriceChange);
	return {
		id,
		question: str(raw.question) || str(raw.groupItemTitle),
		slug: str(raw.slug),
		groupTitle: str(raw.groupItemTitle),
		volume: num(raw.volume),
		volume24h: num(raw.volume24hr) || num(raw.volume24hrClob),
		change24h: change24h || null,
		outcomes: mapOutcomes(raw)
	};
}
function hasYesNo(market) {
	return market.outcomes.some((outcome) => /^yes$/i.test(outcome.label));
}
function isYesNoGroup(markets) {
	if (markets.length < 2) return false;
	const titled = markets.filter((market) => Boolean(market.groupTitle));
	return titled.length >= 2 && titled.every(hasYesNo);
}
function asGroupedYes(market) {
	const yes = primaryOutcome(market);
	if (!yes) return null;
	return {
		...yes,
		label: market.groupTitle || market.question || yes.label,
		change24h: market.change24h,
		volume: market.volume
	};
}
function topOutcomes(event, limit = 3, order = "prob") {
	if (isYesNoGroup(event.markets)) {
		const rows = event.markets.map(asGroupedYes).filter((row) => Boolean(row));
		if (order === "prob") rows.sort((a, b) => b.probability - a.probability);
		return rows.slice(0, limit);
	}
	const headline = event.markets.find((market) => !market.groupTitle || market.groupTitle === event.title || market.question === event.title) ?? event.markets[0];
	if (!headline) return [];
	return [...headline.outcomes].sort((a, b) => b.probability - a.probability).slice(0, limit);
}
function leadingTokenId(event) {
	return topOutcomes(event, 1)[0]?.tokenId ?? null;
}
function normalizeEvent(raw) {
	if (!raw || typeof raw !== "object") return null;
	const event = raw;
	const id = str(event.id);
	const title = str(event.title);
	if (!id || !title) return null;
	const tags = Array.isArray(event.tags) ? event.tags.map((tag) => tag && typeof tag === "object" ? str(tag.label) : str(tag)).filter(Boolean) : [];
	const markets = (Array.isArray(event.markets) ? event.markets : []).map((m) => m && typeof m === "object" ? mapSubMarket(m) : null).filter((m) => Boolean(m));
	if (!isYesNoGroup(markets)) markets.sort((a, b) => {
		const aYes = primaryOutcome(a)?.probability ?? 0;
		const bYes = primaryOutcome(b)?.probability ?? 0;
		return b.volume24h - a.volume24h || bYes - aYes;
	});
	const slug = str(event.slug);
	const draft = {
		id,
		title,
		slug,
		url: slug ? `https://polymarket.com/event/${slug}` : "https://polymarket.com",
		description: str(event.description),
		image: str(event.image) || str(event.icon) || null,
		volume24h: num(event.volume24hr),
		volume: num(event.volume),
		liquidity: num(event.liquidity),
		endDate: str(event.endDate) || null,
		tags,
		category: classifyCategory(title, tags),
		markets,
		leading: null,
		competitive: 0
	};
	const leading = topOutcomes(draft, 1)[0] ?? null;
	const topProb = leading?.probability ?? .5;
	draft.leading = leading;
	draft.competitive = 1 - Math.abs(topProb - .5) * 2;
	return draft;
}
//#endregion
export { topOutcomes as a, primaryOutcome as i, leadingTokenId as n, normalizeEvent as r, isYesNoGroup as t };
