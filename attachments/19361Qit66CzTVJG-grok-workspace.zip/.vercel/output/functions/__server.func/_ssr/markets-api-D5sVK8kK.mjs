import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { r as normalizeEvent } from "./polymarket-ch-FbvOh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/markets-api-D5sVK8kK.js
var GAMMA = "https://gamma-api.polymarket.com";
var CLOB = "https://clob.polymarket.com";
var UA = "DivergeDesk/1.0 (prediction desk; +https://grok.com)";
var listCache = /* @__PURE__ */ new Map();
var LIST_TTL = 45e3;
async function gammaGet(path) {
	const res = await fetch(`${GAMMA}${path}`, {
		headers: {
			Accept: "application/json",
			"User-Agent": UA
		},
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) throw new Error(`Polymarket ${res.status}`);
	return res.json();
}
function asEvents(payload) {
	if (Array.isArray(payload)) return payload;
	if (payload && typeof payload === "object") {
		const rec = payload;
		if (Array.isArray(rec.events)) return rec.events;
		if (Array.isArray(rec.data)) return rec.data;
	}
	return [];
}
async function loadEvents(query) {
	const q = query.trim();
	const key = q ? `q:${q.toLowerCase()}` : "top";
	const hit = listCache.get(key);
	if (hit && Date.now() - hit.at < LIST_TTL) return hit.value;
	const events = asEvents(q ? await gammaGet(`/public-search?q=${encodeURIComponent(q)}&limit=40`) : await gammaGet("/events?active=true&closed=false&order=volume24hr&ascending=false&limit=40")).map(normalizeEvent).filter((event) => Boolean(event)).sort((a, b) => b.volume24h - a.volume24h);
	listCache.set(key, {
		at: Date.now(),
		value: events
	});
	return events;
}
var listMarkets_createServerFn_handler = createServerRpc({
	id: "a6ed2dab3b0e4301c23d298b185ff7768b89888b2a3d0e7420fe51e9054ea16b",
	name: "listMarkets",
	filename: "src/lib/markets-api.ts"
}, (opts) => listMarkets.__executeServer(opts));
var listMarkets = createServerFn({ method: "POST" }).validator((input) => input ?? {}).handler(listMarkets_createServerFn_handler, async ({ data }) => {
	try {
		return {
			ok: true,
			events: await loadEvents(data.q ?? "")
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Could not load markets"
		};
	}
});
var fetchPriceHistory_createServerFn_handler = createServerRpc({
	id: "d4db39ad8fecc12871eef57a284bbe24532a8148bf9753e4f32e94d92c4671af",
	name: "fetchPriceHistory",
	filename: "src/lib/markets-api.ts"
}, (opts) => fetchPriceHistory.__executeServer(opts));
var fetchPriceHistory = createServerFn({ method: "POST" }).validator((input) => input).handler(fetchPriceHistory_createServerFn_handler, async ({ data }) => {
	try {
		const url = `${CLOB}/prices-history?market=${encodeURIComponent(data.tokenId)}&interval=1d&fidelity=60`;
		const res = await fetch(url, {
			headers: {
				Accept: "application/json",
				"User-Agent": UA
			},
			signal: AbortSignal.timeout(1e4)
		});
		if (!res.ok) return {
			ok: false,
			error: `History ${res.status}`
		};
		return {
			ok: true,
			points: ((await res.json()).history ?? []).filter((row) => Number.isFinite(row.t) && Number.isFinite(row.p)).map((row) => ({
				t: row.t,
				p: row.p
			}))
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "No history"
		};
	}
});
async function midpointFor(tokenId) {
	const res = await fetch(`${CLOB}/midpoint?token_id=${encodeURIComponent(tokenId)}`, {
		headers: {
			Accept: "application/json",
			"User-Agent": UA
		},
		signal: AbortSignal.timeout(6e3)
	});
	if (!res.ok) return null;
	const body = await res.json();
	const n = typeof body.mid === "number" ? body.mid : Number(body.mid);
	return Number.isFinite(n) ? n : null;
}
var fetchMidpoints_createServerFn_handler = createServerRpc({
	id: "f55d2c45103d277a870c120dc664a0d878cd11ba4bf3c09da72ea477cde282ba",
	name: "fetchMidpoints",
	filename: "src/lib/markets-api.ts"
}, (opts) => fetchMidpoints.__executeServer(opts));
var fetchMidpoints = createServerFn({ method: "POST" }).validator((input) => input).handler(fetchMidpoints_createServerFn_handler, async ({ data }) => {
	const tokenIds = [...new Set(data.tokenIds.filter(Boolean))].slice(0, 32);
	const prices = {};
	const chunk = 8;
	try {
		for (let i = 0; i < tokenIds.length; i += chunk) {
			const slice = tokenIds.slice(i, i + chunk);
			const rows = await Promise.all(slice.map(async (id) => {
				const mid = await midpointFor(id);
				return mid == null ? null : [id, mid];
			}));
			for (const row of rows) if (row) prices[row[0]] = row[1];
		}
		return {
			ok: true,
			prices
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "No live prices"
		};
	}
});
//#endregion
export { fetchMidpoints_createServerFn_handler, fetchPriceHistory_createServerFn_handler, listMarkets_createServerFn_handler };
