import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, c as DialogTrigger$1, i as DialogDescription$1, l as Slot, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { a as topOutcomes, i as primaryOutcome, n as leadingTokenId, t as isYesNoGroup } from "./polymarket-ch-FbvOh.mjs";
import { a as Star, c as LoaderCircle, d as Check, f as Bookmark, i as TrendingDown, l as ExternalLink, o as Search, p as ArrowLeft, r as TrendingUp, s as RefreshCw, t as X, u as Copy } from "../_libs/lucide-react.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as listMarkets, i as fetchPriceHistory, n as Route, o as createSsrRpc, r as fetchMidpoints } from "./router-C1TH5UNc.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-klnDbCxR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium tracking-wide uppercase", {
	variants: { tone: {
		muted: "bg-raised text-muted",
		sage: "bg-sage-dim text-sage",
		clay: "bg-clay-dim text-clay",
		amber: "bg-amber-dim text-amber",
		paper: "bg-fg/10 text-fg"
	} },
	defaultVariants: { tone: "muted" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/30 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-raised",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-raised",
			sage: "bg-sage text-accent-fg hover:opacity-90",
			clay: "bg-clay text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-sm bg-raised px-3 text-sm text-fg shadow-[var(--shadow-border)]", "placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out", "focus-visible:outline-none focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-fg/25", "disabled:opacity-40", className),
		...props
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-sm bg-raised", className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-bg/70", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-surface p-4 shadow-[var(--shadow-border)]", "sm:inset-auto sm:top-1/2 sm:left-1/2 sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-xl sm:p-6", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "absolute top-3 right-3 size-9",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function formatUsd(value) {
	const n = Number.isFinite(value) ? value : 0;
	const abs = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	if (abs >= 1e9) return `${sign}$${(abs / 1e9).toFixed(1)}B`;
	if (abs >= 1e6) return `${sign}$${(abs / 1e6).toFixed(1)}M`;
	if (abs >= 1e4) return `${sign}$${(abs / 1e3).toFixed(0)}K`;
	if (abs >= 1e3) return `${sign}$${(abs / 1e3).toFixed(1)}K`;
	return `${sign}$${abs.toFixed(0)}`;
}
function formatPct(probability, digits) {
	const pct = (Number.isFinite(probability) ? probability : 0) * 100;
	const d = digits ?? (pct >= 99.5 || pct < 1 ? 1 : 0);
	return `${pct.toFixed(d)}%`;
}
function formatCents(probability) {
	const cents = (Number.isFinite(probability) ? probability : 0) * 100;
	if (cents < 10 || cents > 90) return `${Math.max(0, cents).toFixed(1)}¢`;
	return `${Math.round(cents)}¢`;
}
function formatRelChange(delta, price) {
	if (delta == null || !Number.isFinite(delta) || !Number.isFinite(price)) return null;
	if (Math.abs(delta) < 5e-4) return null;
	const prev = price - delta;
	if (Math.abs(prev) < 5e-4) return null;
	const rel = delta / Math.abs(prev) * 100;
	if (!Number.isFinite(rel) || Math.abs(rel) < .5) return null;
	return {
		text: `${Math.abs(rel).toFixed(0)}%`,
		dir: rel >= 0 ? "up" : "down"
	};
}
function formatEndDate(iso) {
	if (!iso) return "Open";
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "Open";
	return date.toLocaleDateString(void 0, {
		month: "short",
		day: "numeric",
		year: date.getFullYear() !== (/* @__PURE__ */ new Date()).getFullYear() ? "numeric" : void 0
	});
}
function relativeTime(iso) {
	const date = iso instanceof Date ? iso : new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	const diff = Date.now() - date.getTime();
	const sec = Math.round(diff / 1e3);
	if (sec < 10) return "just now";
	if (sec < 60) return `${sec}s ago`;
	const min = Math.round(sec / 60);
	if (min < 60) return `${min}m ago`;
	const hr = Math.round(min / 60);
	if (hr < 24) return `${hr}h ago`;
	return `${Math.round(hr / 24)}d ago`;
}
function clockNow() {
	return (/* @__PURE__ */ new Date()).toLocaleTimeString(void 0, {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false
	});
}
var CATEGORY_LABEL = {
	all: "All",
	politics: "Politics",
	finance: "Finance",
	sports: "Sports",
	crypto: "Crypto",
	world: "World",
	culture: "Culture",
	other: "Other"
};
var SCAN_COPY = {
	overhyped: {
		title: "Overhyped",
		tone: "clay",
		blurb: "The timeline is louder than the book."
	},
	under_radar: {
		title: "Under the radar",
		tone: "sage",
		blurb: "Capital is priced. The crowd has not noticed."
	},
	consensus: {
		title: "Consensus",
		tone: "muted",
		blurb: "Odds and narrative are walking in step."
	},
	contested: {
		title: "Contested",
		tone: "amber",
		blurb: "A coin-flip in the book, a fight on the timeline."
	}
};
var useDeskStore = create()(persist((set, get) => ({
	watchlist: [],
	briefs: [],
	toggleWatch: (id) => {
		const current = get().watchlist;
		set({ watchlist: current.includes(id) ? current.filter((x) => x !== id) : [id, ...current] });
	},
	saveBrief: (brief) => {
		set({ briefs: [brief, ...get().briefs.filter((b) => b.eventId !== brief.eventId)].slice(0, 40) });
	},
	removeBrief: (eventId) => {
		set({ briefs: get().briefs.filter((b) => b.eventId !== eventId) });
	}
}), {
	name: "diverge-desk",
	skipHydration: true
}));
function BriefsDialog({ onOpenEvent }) {
	const briefs = useDeskStore((s) => s.briefs);
	const removeBrief = useDeskStore((s) => s.removeBrief);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "ghost",
			size: "sm",
			className: "relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Briefs"
				}),
				briefs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-1 tabular-nums text-sage",
					children: briefs.length
				}) : null
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Saved briefs" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Stored on this device. Copy the thread from a market after reopening it." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "desk-scroll mt-4 flex-1 overflow-y-auto pr-1",
			children: briefs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted",
				children: "Scan a market, then save the brief."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: briefs.map((brief) => {
					const copy = SCAN_COPY[brief.label];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "min-w-0 text-left",
								onClick: () => onOpenEvent(brief.eventId),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: brief.eventTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 line-clamp-2 text-xs text-muted",
									children: brief.headline
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: copy.tone,
								children: copy.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between text-xs text-subtle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									brief.leadingLabel,
									" ",
									formatPct(brief.leadingPct),
									" ·",
									" ",
									relativeTime(brief.savedAt || brief.scannedAt)
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "hover:text-clay",
								onClick: () => removeBrief(brief.eventId),
								children: "Remove"
							})]
						})]
					}, brief.eventId);
				})
			})
		})
	] })] });
}
function useTickFlash(value) {
	const prev = (0, import_react.useRef)(null);
	const [flash, setFlash] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const last = prev.current;
		prev.current = value;
		if (last == null || Math.abs(value - last) < 5e-4) return;
		setFlash(value > last ? "up" : "down");
		const id = window.setTimeout(() => setFlash(null), 900);
		return () => window.clearTimeout(id);
	}, [value]);
	return flash;
}
function LivePct({ value }) {
	const flash = useTickFlash(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-medium tabular-nums text-fg transition-colors duration-500 ease-[var(--ease-out)]", flash === "up" && "text-sage", flash === "down" && "text-clay"),
		children: formatPct(value)
	});
}
function ChangeChip({ outcome }) {
	const change = formatRelChange(outcome.change24h ?? null, outcome.probability);
	if (!change) return null;
	const Icon = change.dir === "up" ? TrendingUp : TrendingDown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-0.5 text-xs tabular-nums", change.dir === "up" ? "text-sage" : "text-clay"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }), change.text]
	});
}
function OutcomeBars({ outcomes, compact = false }) {
	if (!outcomes.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col", compact ? "gap-1.5" : "gap-2.5"),
		children: outcomes.map((outcome, index) => {
			const pct = Math.max(0, Math.min(100, outcome.probability * 100));
			const dominant = outcome.probability >= .5;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("truncate text-sm", compact ? "text-muted" : "text-fg"),
						children: outcome.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex shrink-0 items-baseline gap-1.5",
						children: [!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeChip, { outcome }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePct, { value: outcome.probability })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full transition-[width] duration-500 ease-[var(--ease-out)]", dominant ? "bg-sage" : "bg-fg/40"),
						style: { width: `${pct}%` }
					})
				})]
			}, `${outcome.label}-${index}`);
		})
	});
}
function DivergenceMeter({ score, label }) {
	const clamped = Math.max(0, Math.min(100, score));
	const copy = SCAN_COPY[label];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-raised p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-subtle uppercase",
					children: "Divergence"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-5xl leading-none tracking-tight tabular-nums",
					children: Math.round(clamped)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: copy.tone,
					children: copy.title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: copy.blurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-1.5 overflow-hidden rounded-full bg-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1/2 bg-sage/35" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1/2 bg-clay/35" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg shadow-[var(--shadow-border)] transition-[left] duration-500 ease-[var(--ease-out)]",
						style: { left: `${clamped}%` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-between text-xs text-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Capital leads" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Aligned" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Crowd leads" })
						]
					})
				]
			})
		]
	});
}
async function copyText(text) {
	await navigator.clipboard.writeText(text);
}
function ThreadComposer({ tweets }) {
	const [copied, setCopied] = (0, import_react.useState)(null);
	async function copyOne(index) {
		await copyText(tweets[index] ?? "");
		setCopied(index);
		toast.success("Post copied");
		window.setTimeout(() => setCopied((c) => c === index ? null : c), 1400);
	}
	async function copyAll() {
		await copyText(tweets.map((tweet, i) => `${i + 1}/${tweets.length}\n${tweet}`).join("\n\n"));
		setCopied("all");
		toast.success("Thread copied");
		window.setTimeout(() => setCopied((c) => c === "all" ? null : c), 1400);
	}
	const first = tweets[0] ?? "";
	const intent = `https://x.com/intent/tweet?text=${encodeURIComponent(first)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-center justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-xs font-medium tracking-widest text-subtle uppercase",
			children: "Thread"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				onClick: copyAll,
				children: [copied === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy all"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: intent,
					target: "_blank",
					rel: "noreferrer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {}), "Open X"]
				})
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-2",
		children: tweets.map((tweet, i) => {
			const over = tweet.length > 280;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md bg-raised p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs tabular-nums text-subtle",
						children: [
							i + 1,
							"/",
							tweets.length
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("text-xs tabular-nums", over ? "text-clay" : "text-subtle"),
							children: [tweet.length, "/280"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => copyOne(i),
							className: "text-muted hover:text-fg",
							"aria-label": `Copy post ${i + 1}`,
							children: copied === i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed whitespace-pre-wrap",
					children: tweet
				})]
			}, `${i}-${tweet.slice(0, 24)}`);
		})
	})] });
}
var scanEvent = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("58b01a7499929131687fd53a5c345e6dd8a0b4dfb8cc780203e079c446cf32f2"));
var STAGES = [
	"Searching X for the last 48 hours",
	"Reading the tape against the book",
	"Scoring crowd vs. capital",
	"Drafting the thread"
];
function toBrief(event, result) {
	const lead = topOutcomes(event, 1)[0];
	return {
		...result,
		eventId: event.id,
		eventTitle: event.title,
		slug: event.slug,
		leadingLabel: lead?.label ?? "",
		leadingPct: lead?.probability ?? 0,
		savedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function ScanPanel({ event, initial }) {
	const saveBrief = useDeskStore((s) => s.saveBrief);
	const saved = useDeskStore((s) => s.briefs).some((b) => b.eventId === event.id);
	const [result, setResult] = (0, import_react.useState)(initial ?? null);
	const [stage, setStage] = (0, import_react.useState)(0);
	const outcomes = (0, import_react.useMemo)(() => topOutcomes(event, 8).map((o) => ({
		label: o.label,
		probability: o.probability
	})), [event]);
	const mutation = useMutation({
		mutationFn: async () => {
			const timer = window.setInterval(() => {
				setStage((s) => (s + 1) % STAGES.length);
			}, 2200);
			try {
				const response = await scanEvent({ data: {
					eventId: event.id,
					title: event.title,
					slug: event.slug,
					description: event.description,
					volume24h: event.volume24h,
					endDate: event.endDate,
					outcomes
				} });
				if (!response.ok) throw new Error(response.error);
				return response.result;
			} finally {
				window.clearInterval(timer);
			}
		},
		onSuccess: (scan) => {
			setResult(scan);
			toast.success("Scan complete");
		},
		onError: (err) => {
			toast.error(err.message || "Scan failed");
		}
	});
	function persist() {
		if (!result) return;
		saveBrief(toBrief(event, result));
		toast.success("Brief saved on this device");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-subtle uppercase",
					children: "Grok scan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-2xl tracking-tight",
					children: "Crowd vs. capital"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setStage(0);
						mutation.mutate();
					},
					disabled: mutation.isPending,
					className: "min-w-40",
					children: mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "Scanning"] }) : result ? "Rescan" : "Scan X vs. book"
				})]
			}),
			mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-lg bg-raised px-4 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shimmer-text text-sm",
					children: STAGES[stage]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-subtle",
					children: [
						"Live X search · ",
						formatUsd(event.volume24h),
						" on the contract"
					]
				})]
			}) : null,
			result && !mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-6 animate-fade-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivergenceMeter, {
						score: result.divergenceScore,
						label: result.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-display text-2xl leading-snug tracking-tight",
						children: result.headline
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: result.thesis
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCard, {
							title: "Crowd",
							body: result.crowdRead
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCard, {
							title: "Capital",
							body: result.capitalRead
						})]
					}),
					result.catalysts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "text-xs font-medium tracking-widest text-subtle uppercase",
						children: "Catalysts"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-col gap-1.5",
						children: result.catalysts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-fg before:mr-2 before:text-subtle before:content-['–']",
							children: c
						}, c))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "Watch · "
						}), result.watch]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadComposer, { tweets: result.thread }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "mb-2 text-xs font-medium tracking-widest text-subtle uppercase",
						children: "Editorial memo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: result.memo
					})] }),
					result.citations.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "mb-2 text-xs font-medium tracking-widest text-subtle uppercase",
						children: "Sources"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1",
						children: result.citations.map((cite, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-xs text-muted",
							children: [cite.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: cite.url,
								target: "_blank",
								rel: "noreferrer",
								className: "text-fg underline decoration-border-strong underline-offset-2 hover:text-sage",
								children: cite.source
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: cite.source
							}), cite.note ? ` — ${cite.note}` : ""]
						}, `${cite.source}-${i}`))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 text-xs text-subtle",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							result.model,
							" · ",
							new Date(result.scannedAt).toLocaleTimeString()
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: persist,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn(saved && "fill-current") }), saved ? "Saved" : "Save brief"]
						})]
					})
				]
			}) : null,
			!result && !mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "Run a scan to pull live posts from X, score them against these odds, and draft a five-post thread you can copy."
			}) : null
		]
	});
}
function ReadCard({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-raised p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-widest text-subtle uppercase",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed",
			children: body
		})]
	});
}
function Sparkline({ points, className }) {
	if (points.length < 2) return null;
	const width = 160;
	const height = 36;
	const pad = 1;
	const values = points.map((p) => p.p);
	const min = Math.min(...values);
	const max = Math.max(...values);
	const span = Math.max(max - min, .01);
	const coords = points.map((point, i) => {
		const x = pad + i / (points.length - 1) * 158;
		const y = pad + (1 - (point.p - min) / span) * 34;
		return `${x.toFixed(1)},${y.toFixed(1)}`;
	});
	const stroke = values[values.length - 1] >= values[0] ? "var(--color-sage)" : "var(--color-clay)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${width} ${height}`,
		className: cn("h-9 w-40 overflow-visible", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
			fill: "none",
			stroke,
			strokeWidth: "1.5",
			strokeLinejoin: "round",
			strokeLinecap: "round",
			points: coords.join(" ")
		})
	});
}
function MarketDetail({ event, onBack }) {
	const [imgFailed, setImgFailed] = (0, import_react.useState)(false);
	const saved = useDeskStore((s) => s.briefs).find((b) => b.eventId === event.id);
	const yesNo = isYesNoGroup(event.markets);
	const outcomes = topOutcomes(event, 8, yesNo ? "book" : "prob");
	const tokenId = leadingTokenId(event);
	const history = useQuery({
		queryKey: ["history", tokenId],
		queryFn: async () => {
			if (!tokenId) return [];
			const res = await fetchPriceHistory({ data: { tokenId } });
			return res.ok ? res.points : [];
		},
		enabled: Boolean(tokenId),
		staleTime: 12e4
	});
	const extraMarkets = !yesNo && event.markets.length > 1 ? event.markets.slice(0, 8) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "px-4 py-5 sm:px-8 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 flex items-center gap-2 lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onBack,
					className: "pl-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), "Markets"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5 sm:flex-row sm:items-start",
				children: [
					event.image && !imgFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: event.image,
						alt: "",
						onError: () => setImgFailed(true),
						className: "size-20 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-20 shrink-0 items-center justify-center rounded-md bg-raised text-xs tracking-widest text-subtle uppercase",
						children: CATEGORY_LABEL[event.category]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: CATEGORY_LABEL[event.category] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted",
									children: ["Ends ", formatEndDate(event.endDate)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-2 font-display text-3xl leading-tight tracking-tight sm:text-4xl",
								children: event.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums text-fg",
										children: [formatUsd(event.volume24h), " 24h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [formatUsd(event.volume), " total vol"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [formatUsd(event.liquidity), " liquidity"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: event.url,
										target: "_blank",
										rel: "noreferrer",
										className: "inline-flex items-center gap-1 text-fg hover:text-sage",
										children: ["Polymarket", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
									})
								]
							})
						]
					}),
					history.data && history.data.length > 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden shrink-0 sm:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-right text-xs text-subtle",
							children: "Leading price"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, { points: history.data })]
					}) : null
				]
			}),
			event.tags.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-1.5",
				children: event.tags.slice(0, 8).map((tag, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "muted",
					className: "normal-case tracking-normal",
					children: tag
				}, `${tag}-${i}`))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mb-3 flex items-center gap-2 text-xs font-medium tracking-widest text-subtle uppercase",
					children: ["Implied probability", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-sans text-sage normal-case tracking-normal",
						children: "live"
					})]
				}), yesNo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookTable, { markets: event.markets }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutcomeBars, { outcomes })]
			}),
			extraMarkets.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-xs font-medium tracking-widest text-subtle uppercase",
					children: "Related contracts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border rounded-md bg-raised px-3",
					children: extraMarkets.map((market) => {
						const top = primaryOutcome(market);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 truncate text-sm",
								children: market.groupTitle || market.question
							}), top ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-sm tabular-nums text-muted",
								children: formatPct(top.probability)
							}) : null]
						}, market.id);
					})
				})]
			}) : null,
			event.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-6 group",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm text-muted hover:text-fg",
					children: "Resolution rules"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed whitespace-pre-wrap text-muted",
					children: event.description
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanPanel, {
				event,
				initial: saved ?? null
			})
		]
	});
}
function BookTable({ markets }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border overflow-hidden rounded-md bg-surface shadow-[var(--shadow-border)]",
		children: markets.map((market) => {
			const yes = primaryOutcome(market);
			if (!yes) return null;
			const pct = Math.max(0, Math.min(100, yes.probability * 100));
			const change = formatRelChange(market.change24h, yes.probability);
			const Icon = change?.dir === "up" ? TrendingUp : TrendingDown;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "px-3 py-3 sm:px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: market.groupTitle || market.question
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs tabular-nums text-muted",
							children: [formatUsd(market.volume), " vol"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-end gap-2",
							children: [change ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("inline-flex items-center gap-0.5 text-xs tabular-nums", change.dir === "up" ? "text-sage" : "text-clay"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }), change.text]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-base font-medium tabular-nums",
								children: formatPct(yes.probability)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs tabular-nums text-muted",
							children: [
								"Yes ",
								formatCents(yes.probability),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-subtle",
									children: " · "
								}),
								"No ",
								formatCents(1 - yes.probability)
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full transition-[width] duration-500 ease-[var(--ease-out)]", yes.probability >= .5 ? "bg-sage" : "bg-fg/40"),
						style: { width: `${pct}%` }
					})
				})]
			}, market.id);
		})
	});
}
function MarketList({ events, selectedId, watchlist, onSelect, onToggleWatch }) {
	if (!events.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-16 text-center text-sm text-muted",
		children: "No live markets match this filter."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2 p-3",
		children: events.map((event, index) => {
			const selected = event.id === selectedId;
			const watched = watchlist.includes(event.id);
			const outcomes = topOutcomes(event, 3);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onSelect(event.id),
				className: cn("w-full rounded-lg p-3 text-left transition-[box-shadow,background-color] duration-150 ease-out", selected ? "bg-raised shadow-[var(--shadow-border-hover)]" : "bg-surface shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-6 shrink-0 text-xs tabular-nums text-subtle",
						children: String(index + 1).padStart(2, "0")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm leading-snug font-medium",
									children: event.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									role: "button",
									tabIndex: 0,
									"aria-label": watched ? "Remove from watchlist" : "Add to watchlist",
									onClick: (e) => {
										e.stopPropagation();
										onToggleWatch(event.id);
									},
									onKeyDown: (e) => {
										if (e.key === "Enter" || e.key === " ") {
											e.preventDefault();
											e.stopPropagation();
											onToggleWatch(event.id);
										}
									},
									className: cn("mt-0.5 shrink-0 after:absolute after:top-1/2 after:left-1/2 after:size-10 after:-translate-x-1/2 after:-translate-y-1/2", "relative text-subtle hover:text-fg", watched && "text-amber"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-3.5", watched && "fill-current") })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "uppercase tracking-wide",
										children: CATEGORY_LABEL[event.category]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [formatUsd(event.volume24h), " 24h"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutcomeBars, {
									outcomes,
									compact: true
								})
							})
						]
					})]
				})
			}) }, event.id);
		})
	});
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setHydrated(true), []);
	return hydrated;
}
var CLOB_MARKET_WS = "wss://ws-subscriptions-clob.polymarket.com/ws/market";
function num(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return n;
	}
	return null;
}
function clampProb(value) {
	return Math.min(1, Math.max(0, value));
}
/** Tight book → midpoint. Wide book (illiquid Yes tokens) → last print, never 50/50. */
function impliedPrice(tick) {
	const { bid, ask, last } = tick;
	if (bid != null && ask != null && ask >= bid && ask - bid <= .08) return clampProb((bid + ask) / 2);
	if (last != null) return clampProb(last);
	return null;
}
function bestLevel(levels, pick) {
	if (!Array.isArray(levels) || !levels.length) return null;
	let best = null;
	for (const row of levels) {
		if (!row || typeof row !== "object") continue;
		const price = num(row.price);
		if (price == null) continue;
		if (best == null) best = price;
		else best = pick === "max" ? Math.max(best, price) : Math.min(best, price);
	}
	return best;
}
function mergeTick(prev, patch) {
	return {
		tokenId: patch.tokenId,
		bid: patch.bid !== void 0 ? patch.bid : prev?.bid ?? null,
		ask: patch.ask !== void 0 ? patch.ask : prev?.ask ?? null,
		last: patch.last !== void 0 ? patch.last : prev?.last ?? null,
		at: patch.at ?? Date.now()
	};
}
function asRecord(value) {
	return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function ticksFromEvent(raw, at) {
	const rec = asRecord(raw);
	if (!rec) return [];
	const type = typeof rec.event_type === "string" ? rec.event_type : "";
	if (type === "price_change" && Array.isArray(rec.price_changes)) {
		const out = [];
		for (const change of rec.price_changes) {
			const row = asRecord(change);
			if (!row) continue;
			const tokenId = typeof row.asset_id === "string" ? row.asset_id : "";
			if (!tokenId) continue;
			out.push({
				tokenId,
				bid: num(row.best_bid),
				ask: num(row.best_ask),
				last: null,
				at
			});
		}
		return out;
	}
	const tokenId = typeof rec.asset_id === "string" ? rec.asset_id : "";
	if (!tokenId) return [];
	if (type === "last_trade_price") return [{
		tokenId,
		bid: null,
		ask: null,
		last: num(rec.price),
		at
	}];
	if (type === "best_bid_ask") return [{
		tokenId,
		bid: num(rec.best_bid),
		ask: num(rec.best_ask),
		last: null,
		at
	}];
	if (type === "book" || Array.isArray(rec.bids) || Array.isArray(rec.asks)) return [{
		tokenId,
		bid: bestLevel(rec.bids, "max"),
		ask: bestLevel(rec.asks, "min"),
		last: num(rec.last_trade_price),
		at
	}];
	return [];
}
function parseTapeFrame(raw, at = Date.now()) {
	const text = raw.trim();
	if (!text || text === "PONG" || text === "PING") return [];
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return [];
	}
	const items = Array.isArray(payload) ? payload : [payload];
	const ticks = [];
	for (const item of items) ticks.push(...ticksFromEvent(item, at));
	return ticks.filter((tick) => tick.bid != null || tick.ask != null || tick.last != null);
}
function collectTokenIds(events, selectedId, limit = 80) {
	const ids = [];
	const seen = /* @__PURE__ */ new Set();
	function add(tokenId) {
		if (!tokenId || seen.has(tokenId)) return;
		seen.add(tokenId);
		ids.push(tokenId);
	}
	for (const event of events) for (const outcome of topOutcomes(event, 3)) add(outcome.tokenId);
	const selected = events.find((event) => event.id === selectedId);
	if (selected) for (const market of selected.markets) for (const outcome of market.outcomes) add(outcome.tokenId);
	return ids.slice(0, limit);
}
function overlayEvent(event, ticks) {
	let changed = false;
	const markets = event.markets.map((market) => {
		let marketChanged = false;
		const outcomes = market.outcomes.map((outcome) => {
			if (!outcome.tokenId) return outcome;
			const tick = ticks[outcome.tokenId];
			if (!tick) return outcome;
			const next = impliedPrice(tick);
			if (next == null || Math.abs(next - outcome.probability) < 5e-5) return outcome;
			marketChanged = true;
			changed = true;
			return {
				...outcome,
				probability: next
			};
		});
		return marketChanged ? {
			...market,
			outcomes
		} : market;
	});
	if (!changed) return event;
	const next = {
		...event,
		markets,
		leading: null,
		competitive: 0
	};
	const leading = topOutcomes(next, 1)[0] ?? null;
	next.leading = leading;
	next.competitive = 1 - Math.abs((leading?.probability ?? .5) - .5) * 2;
	return next;
}
var CATEGORIES = [
	"all",
	"politics",
	"finance",
	"sports",
	"crypto",
	"world",
	"culture"
];
var PING_MS = 1e4;
var FLUSH_MS = 200;
var FALLBACK_MS = 4e3;
var RECONNECT_MAX = 12e3;
function useLiveTape(tokenIds) {
	const [ticks, setTicks] = (0, import_react.useState)({});
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [lastTickAt, setLastTickAt] = (0, import_react.useState)(null);
	const ticksRef = (0, import_react.useRef)(ticks);
	ticksRef.current = ticks;
	const pendingRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const flushTimer = (0, import_react.useRef)(null);
	const liveRef = (0, import_react.useRef)(false);
	const socketRef = (0, import_react.useRef)(null);
	const subscribedRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const idsRef = (0, import_react.useRef)([]);
	const idsKey = tokenIds.join("|");
	const ids = (0, import_react.useMemo)(() => idsKey ? idsKey.split("|") : [], [idsKey]);
	idsRef.current = ids;
	function flushSoon() {
		if (flushTimer.current != null) return;
		flushTimer.current = window.setTimeout(() => {
			flushTimer.current = null;
			const batch = pendingRef.current;
			if (!batch.size) return;
			pendingRef.current = /* @__PURE__ */ new Map();
			setTicks((current) => {
				const next = { ...current };
				for (const [id, tick] of batch) next[id] = tick;
				return next;
			});
			setLastTickAt(Date.now());
		}, FLUSH_MS);
	}
	function applyTicks(incoming) {
		if (!incoming.length) return;
		for (const tick of incoming) {
			const prev = pendingRef.current.get(tick.tokenId) ?? ticksRef.current[tick.tokenId];
			pendingRef.current.set(tick.tokenId, mergeTick(prev, tick));
		}
		flushSoon();
	}
	const applyRef = (0, import_react.useRef)(applyTicks);
	applyRef.current = applyTicks;
	(0, import_react.useEffect)(() => {
		if (typeof WebSocket === "undefined") {
			liveRef.current = false;
			setStatus("idle");
			return;
		}
		if (!idsKey) {
			liveRef.current = false;
			setStatus("idle");
			return;
		}
		let closed = false;
		let ping = null;
		let reconnect = null;
		let attempt = 0;
		function subscribe(ws, nextIds) {
			if (ws.readyState !== WebSocket.OPEN) return;
			const subscribed = subscribedRef.current;
			const next = new Set(nextIds);
			const drop = [...subscribed].filter((id) => !next.has(id));
			if (drop.length) {
				ws.send(JSON.stringify({
					assets_ids: drop,
					operation: "unsubscribe"
				}));
				for (const id of drop) subscribed.delete(id);
			}
			ws.send(JSON.stringify({
				assets_ids: nextIds,
				type: "market",
				custom_feature_enabled: true
			}));
			subscribed.clear();
			for (const id of nextIds) subscribed.add(id);
		}
		function connect() {
			if (closed) return;
			liveRef.current = false;
			setStatus((current) => current === "polling" ? "polling" : "connecting");
			const ws = new WebSocket(CLOB_MARKET_WS);
			socketRef.current = ws;
			ws.addEventListener("open", () => {
				if (closed || socketRef.current !== ws) return;
				attempt = 0;
				liveRef.current = true;
				setStatus("live");
				subscribe(ws, idsRef.current);
				ping = window.setInterval(() => {
					if (ws.readyState === WebSocket.OPEN) ws.send("PING");
				}, PING_MS);
			});
			ws.addEventListener("message", (event) => {
				if (closed || socketRef.current !== ws) return;
				const raw = typeof event.data === "string" ? event.data : "";
				if (!raw) return;
				applyRef.current(parseTapeFrame(raw));
			});
			ws.addEventListener("close", () => {
				if (socketRef.current === ws) socketRef.current = null;
				liveRef.current = false;
				subscribedRef.current.clear();
				if (ping != null) window.clearInterval(ping);
				ping = null;
				if (closed) return;
				setStatus("polling");
				const wait = Math.min(RECONNECT_MAX, 800 * 2 ** attempt);
				attempt += 1;
				reconnect = window.setTimeout(connect, wait);
			});
			ws.addEventListener("error", () => {
				try {
					ws.close();
				} catch {}
			});
		}
		connect();
		return () => {
			closed = true;
			liveRef.current = false;
			if (ping != null) window.clearInterval(ping);
			if (reconnect != null) window.clearTimeout(reconnect);
			try {
				socketRef.current?.close();
			} catch {}
			socketRef.current = null;
			subscribedRef.current.clear();
		};
	}, [idsKey ? "on" : "off"]);
	(0, import_react.useEffect)(() => {
		const ws = socketRef.current;
		if (!ws || ws.readyState !== WebSocket.OPEN || !ids.length) return;
		ws.send(JSON.stringify({
			assets_ids: ids,
			type: "market",
			custom_feature_enabled: true
		}));
		subscribedRef.current = new Set(ids);
	}, [ids, idsKey]);
	(0, import_react.useEffect)(() => {
		if (!ids.length) return;
		let cancelled = false;
		let timer = null;
		async function poll() {
			if (cancelled) return;
			if (liveRef.current) {
				timer = window.setTimeout(poll, FALLBACK_MS);
				return;
			}
			setStatus((current) => current === "live" ? current : "polling");
			try {
				const res = await fetchMidpoints({ data: { tokenIds: idsRef.current } });
				if (!cancelled && res.ok) {
					const at = Date.now();
					applyRef.current(Object.entries(res.prices).map(([tokenId, last]) => ({
						tokenId,
						bid: null,
						ask: null,
						last,
						at
					})));
				}
			} catch {}
			if (!cancelled) timer = window.setTimeout(poll, FALLBACK_MS);
		}
		const start = window.setTimeout(poll, 2500);
		return () => {
			cancelled = true;
			window.clearTimeout(start);
			if (timer != null) window.clearTimeout(timer);
		};
	}, [idsKey]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (flushTimer.current != null) window.clearTimeout(flushTimer.current);
		};
	}, []);
	return {
		ticks,
		status,
		lastTickAt
	};
}
function Desk({ initialEvents = [] }) {
	const hydrated = useHydrated();
	const watchlist = useDeskStore((s) => s.watchlist);
	const toggleWatch = useDeskStore((s) => s.toggleWatch);
	const [query, setQuery] = (0, import_react.useState)("");
	const [debounced, setDebounced] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("volume");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [clock, setClock] = (0, import_react.useState)("");
	const [desktop, setDesktop] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		useDeskStore.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		setClock(clockNow());
		const id = window.setInterval(() => setClock(clockNow()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(min-width: 1024px)");
		const apply = () => setDesktop(media.matches);
		apply();
		media.addEventListener("change", apply);
		return () => media.removeEventListener("change", apply);
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setTimeout(() => setDebounced(query.trim()), 400);
		return () => window.clearTimeout(id);
	}, [query]);
	const markets = useQuery({
		queryKey: ["markets", debounced],
		queryFn: async () => {
			const res = await listMarkets({ data: { q: debounced } });
			if (!res.ok) throw new Error(res.error);
			return res.events;
		},
		initialData: debounced ? void 0 : initialEvents.length ? initialEvents : void 0,
		staleTime: 4e4,
		refetchInterval: 9e4
	});
	const snapshot = markets.data ?? [];
	const tokenIds = (0, import_react.useMemo)(() => collectTokenIds(snapshot, selectedId), [snapshot, selectedId]);
	const tape = useLiveTape(hydrated ? tokenIds : []);
	const events = (0, import_react.useMemo)(() => snapshot.map((event) => overlayEvent(event, tape.ticks)), [snapshot, tape.ticks]);
	const filtered = (0, import_react.useMemo)(() => {
		let next = events;
		if (category !== "all") next = next.filter((event) => event.category === category);
		if (sort === "watched") next = next.filter((event) => watchlist.includes(event.id));
		else if (sort === "tossup") next = [...next].sort((a, b) => b.competitive - a.competitive);
		return next;
	}, [
		events,
		category,
		sort,
		watchlist
	]);
	(0, import_react.useEffect)(() => {
		if (desktop !== true) return;
		if (selectedId || !filtered[0]) return;
		setSelectedId(filtered[0].id);
	}, [
		desktop,
		filtered,
		selectedId
	]);
	const selected = filtered.find((e) => e.id === selectedId) ?? events.find((e) => e.id === selectedId);
	const showList = desktop !== false || !selectedId;
	const showDetail = desktop !== false || Boolean(selectedId);
	const volume24 = events.reduce((sum, e) => sum + e.volume24h, 0);
	const fetchedAt = markets.dataUpdatedAt ? new Date(markets.dataUpdatedAt) : null;
	const tapeLabel = tape.status === "live" ? "LIVE tape" : tape.status === "polling" ? "Polling book" : tape.status === "connecting" ? "Connecting tape" : "Book snapshot";
	function openEvent(id) {
		setSelectedId(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-bg px-4 py-3 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-subtle uppercase",
							children: "Prediction desk"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-3xl tracking-tight italic sm:text-4xl",
								children: "Diverge"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-xs text-muted sm:inline",
								children: "Capital vs. crowd"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 sm:gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden items-center gap-2 pr-2 text-xs text-muted md:flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("live-dot size-1.5 rounded-full", tape.status === "live" ? "bg-sage" : tape.status === "polling" ? "bg-amber" : "bg-subtle") }), clock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: clock
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: "--:--:--"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BriefsDialog, { onOpenEvent: (id) => {
								setSelectedId(id);
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Refresh markets",
								onClick: () => markets.refetch(),
								disabled: markets.isFetching,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-4", markets.isFetching && "animate-spin") })
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("live-dot size-1.5 rounded-full", tape.status === "live" ? "bg-sage" : tape.status === "polling" ? "bg-amber" : "bg-subtle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase tracking-wide",
								children: tapeLabel
							})]
						}),
						hydrated && tape.lastTickAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "·"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["print ", relativeTime(tape.lastTickAt)] })] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-fg",
							children: [formatUsd(volume24), " 24h"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [events.length, " live markets"]
						}),
						hydrated && fetchedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "·"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["catalog ", relativeTime(fetchedAt)] })] }) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("flex min-h-0 flex-col border-border lg:w-96 lg:shrink-0 lg:border-r", showList ? "flex" : "hidden lg:flex"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: query,
									onChange: (e) => setQuery(e.target.value),
									placeholder: "Search markets",
									className: "pl-9",
									"aria-label": "Search markets"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "desk-scroll mt-3 flex gap-1.5 overflow-x-auto pb-1",
								children: CATEGORIES.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCategory(id),
									className: cn("h-9 shrink-0 rounded-full px-3 text-xs tracking-wide uppercase", category === id ? "bg-fg text-accent-fg" : "bg-raised text-muted hover:text-fg"),
									children: CATEGORY_LABEL[id]
								}, id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex gap-1",
								children: [
									["volume", "Volume"],
									["tossup", "Toss-up"],
									["watched", "Watched"]
								].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSort(key),
									className: cn("h-8 rounded-full px-3 text-xs", sort === key ? "bg-raised text-fg" : "text-subtle hover:text-fg"),
									children: [label, key === "watched" && hydrated && watchlist.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1 tabular-nums text-sage",
										children: watchlist.length
									}) : null]
								}, key))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "desk-scroll min-h-0 flex-1 overflow-y-auto",
						children: markets.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-2 p-3",
							children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 rounded-lg" }, i))
						}) : markets.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-16 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: markets.error instanceof Error ? markets.error.message : "Could not load Polymarket."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								className: "mt-3",
								onClick: () => markets.refetch(),
								children: "Try again"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketList, {
							events: filtered,
							selectedId,
							watchlist: hydrated ? watchlist : [],
							onSelect: openEvent,
							onToggleWatch: toggleWatch
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: cn("desk-scroll min-h-0 flex-1 overflow-y-auto", showDetail ? "block" : "hidden lg:block"),
					children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketDetail, {
						event: selected,
						onBack: () => setSelectedId(null)
					}, selected.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDesk, { loading: markets.isLoading })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-right",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-fg)",
					border: "1px solid var(--color-border)"
				} }
			})
		]
	});
}
function EmptyDesk({ loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-80 flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				tone: "sage",
				children: "Live"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-3xl tracking-tight",
				children: loading ? "Opening the book" : "Pick a market"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm text-muted",
				children: "Live Polymarket odds on the left. Scan any contract against X to see where the crowd and the capital disagree."
			})
		]
	});
}
function Home() {
	const initial = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, { initialEvents: initial });
}
//#endregion
export { Home as component };
