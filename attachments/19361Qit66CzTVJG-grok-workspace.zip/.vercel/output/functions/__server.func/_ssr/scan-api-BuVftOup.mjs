import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-api-BuVftOup.js
var ScanSchema = object({
	divergenceScore: number().min(0).max(100),
	label: _enum([
		"overhyped",
		"under_radar",
		"consensus",
		"contested"
	]),
	headline: string().min(4).max(180),
	thesis: string().min(20).max(1200),
	crowdRead: string().min(8).max(1200),
	capitalRead: string().min(8).max(1200),
	catalysts: array(string()).max(6),
	watch: string().min(4).max(400),
	citations: array(object({
		source: string(),
		url: string().optional(),
		note: string()
	})).max(8),
	thread: array(string().min(8).max(400)).min(3).max(6),
	memo: string().min(80).max(2500)
});
var scanCache = /* @__PURE__ */ new Map();
var SCAN_TTL = 18e5;
function extractJson(text) {
	const trimmed = text.trim();
	const candidate = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? trimmed;
	const start = candidate.indexOf("{");
	const end = candidate.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("Model did not return JSON");
	return JSON.parse(candidate.slice(start, end + 1));
}
function extractOutputText(body) {
	if (!body || typeof body !== "object") return "";
	const rec = body;
	if (typeof rec.output_text === "string" && rec.output_text.trim()) return rec.output_text;
	const parts = [];
	const output = Array.isArray(rec.output) ? rec.output : [];
	for (const item of output) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		const content = Array.isArray(row.content) ? row.content : [];
		for (const block of content) {
			if (!block || typeof block !== "object") continue;
			const c = block;
			if (typeof c.text === "string") parts.push(c.text);
		}
		if (typeof row.text === "string") parts.push(row.text);
	}
	return parts.join("\n");
}
function isoDaysAgo(days) {
	const d = /* @__PURE__ */ new Date();
	d.setUTCDate(d.getUTCDate() - days);
	return d.toISOString().slice(0, 10);
}
function buildPrompt(input) {
	const odds = input.outcomes.slice(0, 8).map((o) => `- ${o.label}: ${(o.probability * 100).toFixed(1)}%`).join("\n");
	return `Analyze this live Polymarket event against discourse on X from the last 48 hours.

EVENT: ${input.title}
URL: https://polymarket.com/event/${input.slug}
24H VOLUME: $${Math.round(input.volume24h).toLocaleString()}
END: ${input.endDate ?? "unspecified"}
IMPLIED PROBABILITIES:
${odds || "- unknown"}

DESCRIPTION (may include resolution rules):
${input.description.slice(0, 1200) || "(none)"}

Tasks:
1. Search X for recent posts about this exact question / the people and outcomes involved.
2. Compare crowd narrative vs the priced odds. Do not invent posts — if X is quiet, say so.
3. Score divergenceScore 0–100 where 50 = narrative and odds agree. Above 50 = social hype/conviction is ahead of (more bullish than) the capital price. Below 50 = capital is more certain than public conversation (under-discussed / under-the-radar). Use "contested" only when odds are near a coin-flip AND X is loudly split.

Return ONLY valid JSON (no markdown) with this shape:
{
  "divergenceScore": number,
  "label": "overhyped" | "under_radar" | "consensus" | "contested",
  "headline": "one sharp sentence",
  "thesis": "2-4 sentences on why the gap exists",
  "crowdRead": "what X is actually saying",
  "capitalRead": "what the contract is pricing and why that might be right or slow",
  "catalysts": ["up to 4 concrete recent catalysts"],
  "watch": "the date, print, or event that resolves or moves this next",
  "citations": [{"source": "handle or outlet", "url": "optional", "note": "what they said"}],
  "thread": ["5 posts, each under 270 characters, no hashtag spam, no emoji. Post 1 must include the leading implied probability."],
  "memo": "180-220 word editorial memo, institutional tone, no legal disclaimers"
}`;
}
async function callGrok(apiKey, prompt, model) {
	const res = await fetch("https://api.x.ai/v1/responses", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model,
			instructions: "You are a quantitative narrative analyst at the intersection of prediction markets and live social discourse. Be specific, cite real posts, never fabricate engagement. Output JSON only.",
			input: prompt,
			tools: [{
				type: "x_search",
				from_date: isoDaysAgo(2)
			}, { type: "web_search" }],
			max_output_tokens: 8e3,
			reasoning: { effort: "low" },
			store: false
		}),
		signal: AbortSignal.timeout(85e3)
	});
	if (!res.ok) {
		const detail = await res.text().catch(() => "");
		throw new Error(`xAI ${res.status}${detail ? `: ${detail.slice(0, 180)}` : ""}`);
	}
	return extractOutputText(await res.json());
}
var scanEvent_createServerFn_handler = createServerRpc({
	id: "58b01a7499929131687fd53a5c345e6dd8a0b4dfb8cc780203e079c446cf32f2",
	name: "scanEvent",
	filename: "src/lib/scan-api.ts"
}, (opts) => scanEvent.__executeServer(opts));
var scanEvent = createServerFn({ method: "POST" }).validator((input) => input).handler(scanEvent_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY?.trim();
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment"
	};
	const cacheKey = `${data.eventId}:${data.outcomes.slice(0, 4).map((o) => `${o.label}:${o.probability.toFixed(2)}`).join("|")}`;
	const hit = scanCache.get(cacheKey);
	if (hit && Date.now() - hit.at < SCAN_TTL) return {
		ok: true,
		result: hit.result
	};
	const models = ["grok-4.6", "grok-4.5"];
	let lastError = "Scan failed";
	const prompt = buildPrompt(data);
	for (const model of models) try {
		const text = await callGrok(apiKey, prompt, model);
		const parsed = ScanSchema.parse(extractJson(text));
		const result = {
			...parsed,
			thread: parsed.thread.map((t) => t.trim()).slice(0, 6),
			catalysts: parsed.catalysts.map((c) => c.trim()).filter(Boolean).slice(0, 4),
			scannedAt: (/* @__PURE__ */ new Date()).toISOString(),
			model
		};
		scanCache.set(cacheKey, {
			at: Date.now(),
			result
		});
		return {
			ok: true,
			result
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : "Scan failed";
		if (lastError.includes("xAI 404") || lastError.includes("xAI 400")) continue;
		if (model === models[models.length - 1]) break;
	}
	return {
		ok: false,
		error: lastError
	};
});
//#endregion
export { scanEvent_createServerFn_handler };
